import javax.swing.JOptionPane;

public class TerceiroPrograma {
	public static void main(String[] args) {
		String mensagem = "Hello World!";
 		JOptionPane.showMessageDialog(null, mensagem);
	}
}