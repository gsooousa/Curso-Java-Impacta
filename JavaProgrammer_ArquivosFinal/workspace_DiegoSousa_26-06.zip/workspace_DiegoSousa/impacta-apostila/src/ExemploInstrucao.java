
public class ExemploInstrucao {

}
