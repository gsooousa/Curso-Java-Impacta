package capitulo13;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AlunoTest {
	
	Aluno a;
	
	@BeforeEach
	void inicializaAluno() {
		 a = new Aluno();
	}
	
	@Test
	void notaNegativa() {
		double nota = -1;
		a.setNota(nota);
		
		assertTrue(a.getNota() == 0);
	}
	
	@Test
	void notaAcima() {
		double nota = 11;
		a.setNota(nota);
		
		assertTrue(a.getNota() == 0);
	}

	
}
