package capitulo05;

import javax.swing.JOptionPane;

import capitulo05.model.Celular;

public class CelularApp {
	public static void main(String[] args) {
		Celular celXiaomi = new Celular();
		Celular celIphone = new Celular();
		
		celXiaomi.setMarca("Xi");
		celXiaomi.modelo = "RedMI";
		
		celIphone.setMarca("Iphone");
		celIphone.modelo = "7 Plus";
		
		System.out.println(celXiaomi.toString());
		JOptionPane.showMessageDialog(null, "Opa! Vamos descansar!");
	}
}
