package capitulo05.laboratorio;

public class Carro {
	String modelo;
	float potenciaMotor;
	String cor;
	
}
