package capitulo05.laboratorio;

public class Lab01 {
	public static void main(String[] args) {
		Funcionario func = new Funcionario();
		
		func.nome = "Alberto";
		func.sobrenome = "Sampaio";
		func.cargo = "Desenvolvedor";
		func.salario = 4892.50F;
		
		System.out.println("Informa��es exibidas individualmente com PRINTLN");
		System.out.println("Nome: " + func.nome);
		System.out.println("Sobrenome: " + func.sobrenome);
		System.out.println("Cargo: " + func.cargo);
		System.out.println("Salario: " + func.salario);
		
		System.out.println("\nInforma��es exibidas atraves de um formato com PRINTF");
		System.out.printf("Nome: %s\nSobrenome: %s\nCargo: %s\nSalario: %.2f",
								func.nome, func.sobrenome, func.cargo, func.salario);
		
		System.out.println("\n\nInforma��es exibidas atraves de um metodo definido na classe");
		func.exibirInformacaoes();
		
	}
}
