package capitulo05.laboratorio;

public enum ModeloCarro {
	VIRTUS,
	FOX,
	JETTA,
	GOL;
}
