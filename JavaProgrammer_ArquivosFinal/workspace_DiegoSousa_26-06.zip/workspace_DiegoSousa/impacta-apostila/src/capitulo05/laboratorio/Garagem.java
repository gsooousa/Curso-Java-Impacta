package capitulo05.laboratorio;

public class Garagem {
	Carro carroPasseio;
	Carro carroUtilitario;
	
	public static void main(String[] args) {
		Garagem g = new Garagem();
		
		g.carroPasseio = new Carro();
		g.carroPasseio.modelo = "Jetta";
		g.carroPasseio.potenciaMotor = 2.0F;
		g.carroPasseio.cor = "Branco";
		
		g.carroUtilitario = new Carro();
		g.carroUtilitario.modelo = "C4 Cactus";
		g.carroUtilitario.potenciaMotor = 1.8f;
		g.carroUtilitario.cor = "Preto";
		
		System.out.printf("Carro de Passeio:\nModelo: %s\nCor: %s\nPot�ncia: %s\n\n",
					g.carroPasseio.modelo, g.carroPasseio.cor, g.carroPasseio.potenciaMotor);
		
		System.out.printf("Carro utilit�rio:\nModelo: %s\nCor: %s\nPot�ncia: %s\n\n",
					g.carroUtilitario.modelo, g.carroUtilitario.cor, g.carroUtilitario.potenciaMotor);
	}
}
