package capitulo05.laboratorio;

public class Funcionario {
	String nome;
	String sobrenome;
	String cargo;
	float salario;
	
	
	public void exibirInformacaoes() {
		System.out.printf("Nome: %s\nSobrenome: %s\nCargo: %s\nSalario: %.2f",
				this.nome, this.sobrenome, this.cargo, this.salario);
	}
}
