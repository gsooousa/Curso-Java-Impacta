package capitulo05.model;

public class Celular {
	private String marca;
	public String modelo;
	double peso;
	double polegadasTela;
	String memoria;
	
	public String getMarca() {
		return marca;
	}
	
	public void setMarca(String marca) {
		if(marca.length() >= 3) {
			this.marca = marca;
		} else {
			System.out.println("amig�o muito pequena essa marca!");
		}
	}
	
	
	public void exibirInformacoes() {
		System.out.println("Marca: " + this.marca);
		System.out.println("Modelo: " + this.modelo);
		System.out.println("Peso: " + this.peso);
		System.out.println("Polegadas da Tela: " + this.polegadasTela);
		System.out.println("Memoria: " + this.memoria);
		System.out.println();
		
	}
	
	@Override
	public String toString() {
		return getClass().getName();
	}
}
