package capitulo05;

public class Pessoa {
	String nome;
	int idade;
	char sexo;
	
}
