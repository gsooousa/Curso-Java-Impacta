package capitulo05;

public class ExemploAtribuicao {
	public static void main(String[] args) {
		Pessoa joao = new Pessoa();
		Pessoa maria = new Pessoa();
		
		joao.nome = "Jo�o";
		joao.idade = 45;
		joao.sexo = 'M';
		
		maria.nome = "Maria";
		maria.idade = 17;
		maria.sexo = 'F';
		
		System.out.println("Jo�o Nome = " +  joao.nome);
		System.out.println("Jo�o Idade = " +  joao.idade);
		System.out.println("Jo�o Sexo = " +  joao.sexo);
		System.out.println();
		System.out.println("Maria Nome = " +  maria.nome);
		System.out.println("Maria Idade = " +  maria.idade);
		System.out.println("Maria Sexo = " +  maria.sexo);
		
		joao = maria;
		joao.idade = 33;
		System.out.println();
		System.out.println("Jo�o Nome = " +  joao.nome);
		System.out.println("Jo�o Idade = " +  joao.idade);
		System.out.println("Jo�o Sexo = " +  joao.sexo);
		System.out.println();
		System.out.println("Maria Nome = " +  maria.nome);
		System.out.println("Maria Idade = " +  maria.idade);
		System.out.println("Maria Sexo = " +  maria.sexo);
		
	}
}
