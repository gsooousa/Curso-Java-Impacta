package capitulo01;

import java.util.Scanner;

public class MensagemUsuarioScanner {
	public static void main(String[] args) {
		// DEFININDO VARIAVEL DO TIPO STRING 
		String nomeAluno;
		
		// DEFININDO UM OBJETO DO TIPO SCANNER 
		Scanner scan = new Scanner(System.in);
		
		// IMPRIMINDO NO CONSOLE O LITERAL STRING
		System.out.print("Digite seu nome: ");
		
		// ATRIBUINDO O QUE FOR CAPTURADO PELO SCANNER NA PROXIMA LINHA DIGITADA PELO USU�RIO
		nomeAluno = scan.nextLine();
		
		// FECHANDO O RECURSO DO OBJETO SCANNER
		scan.close();
		
		// IMPRIMINDO NO CONSOLE O LITERAL STRTING E A VARIAVEL
		System.out.println("Seja Bem Vindo!\n\tAluno: " + nomeAluno);
	}
}
