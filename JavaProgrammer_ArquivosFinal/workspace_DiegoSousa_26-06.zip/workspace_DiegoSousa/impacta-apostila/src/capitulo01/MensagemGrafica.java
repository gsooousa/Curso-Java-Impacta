package capitulo01;

import javax.swing.JOptionPane;

public class MensagemGrafica {
	public static void main(String[] args) {
		//EXIBE O LITERAL STRING ("HELLO JAVA") EM UMA JANELA DE DIALOGO
		JOptionPane.showMessageDialog(null, "Hello Java!");
	}
}
