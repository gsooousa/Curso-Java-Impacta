package capitulo01;

public class MensagemUsuario {
	public static void main(String[] args) {
		// DEFININDO UMA VARI�VEL DO TIPO STRING
		String nomeAluno;
		
		//ATRIBUINDO O VALOR LITERAL "ARTHUR SAUTER" NA VARIAVEL NOMEALUNO
		nomeAluno = "Arthur Sauter";
		
		//IMPRIME O LITERAL STRING E A VARIAVEL ENTRE PARENTESES NO CONSOLE
		System.out.println("Seja Bem Vindo!\n\tAluno: " + nomeAluno);
		
	}
}
