package capitulo01;

public class MensagemConsoleProdutivo {
	public static void main(String[] args) {
		//IMPRIME O LITERAL STRING ENTRE PARENTESES NO CONSOLE
		System.out.println("Estamos apredendo a ser produtivos! Ebaa =)");
	}
}
