package capitulo01;

public class MensagemConsole {
	public static void main(String[] args) {
		//IMPRIME O LITERAL STRING ("HELLO JAVA") NO CONSOLE
		System.out.println("Hello Java!");
	}
}
