package capitulo01;

/**
 * ESTA CLASSE � UTILIZADA PARA EXEMPLIFICAR OS TIPOS DE COMENTARIOS DISPONIVEIS NA LINGUAGEM JAVA
 * 
 * @author Diego Sousa
 * @version.1.0
 * 
 */
public class TiposComentarios {
	public static void main(String[] args) {
		//ESTE � UM COMENTARIO DE LINHA EXEMPLO ABAIXO
		
		// System.out.println("HELLO JAVA!");
		
		/*
		 * ESTE UM COMENTARIO DE BLOCO, INICIANDO EM BARRA ASTERISCO E FINALIZANDO EM ASTERISCO BARRA
		 * SEGUE UM EXEMPLO ABAIXO 
		 */

		/*
		 * String nome;
		 * nome = "Joaquim Floriano";
		 * System.out.println(nome);
		*/ 
	}
}
