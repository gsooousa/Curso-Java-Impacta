package capitulo04;

public class While {
	public static void main(String[] args) {
		int i = 0;
		
		while(i < 10 ) {
			System.out.println("Boa noite! - " +  i);
			i++;
		}
		
		int a = 0, b = 0;
		
		while(a < 6) {
			System.out.println("Principal - " + a);
			while(b < 3) {
				System.out.println("\tInterno - " + b);
				b++;
			}
			b = 0; // INSERIMOS AQUI FORA PARA QUE FOSSE POSS�VEL REINICIALIZAR O LA�O INTERNO
			a++;
		}
				
	
	}
}
