package capitulo04;

import javax.swing.JOptionPane;

public class JogoAcerteNumero {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		int sugestao = 0;
		final int sorteado = (int) (1 + Math.random() * 30);
		String apresentacao = "";
		boolean winner = false;
		
		apresentacao += "Bem vindo ao jogo: \"ADIVINHE SE PUDER!\"\n";
		apresentacao += "VOU SORTEAR UM NUMERO INTEIRO ENTRE 1 E 30 INCLUSIVE\n";
		apresentacao += "TENTE ACERTAR! BOA SORTE!";
		
		JOptionPane.showMessageDialog(null, apresentacao);
		sugestao = Integer.parseInt(JOptionPane.showInputDialog("Digite o n�mero desejado: "));
		System.out.println(sorteado);
		
		jogo: // INSTRU��O ROTULADA
		do {
			
			if(sugestao == sorteado) {
				JOptionPane.showMessageDialog(null, "Parab�ns\nVoc� � incrivel");
				winner = true;
				break jogo; // INTERROMPE O LA�O EM QUEST�O OU O LA�O REFERENCIADO
			} else {
				JOptionPane.showMessageDialog(null, "Oops, Errou!\nTenteNovamente");
				sugestao = Integer.parseInt(JOptionPane.showInputDialog("Digite o n�mero desejado: "));
			}
		} while(true);
	}
}
