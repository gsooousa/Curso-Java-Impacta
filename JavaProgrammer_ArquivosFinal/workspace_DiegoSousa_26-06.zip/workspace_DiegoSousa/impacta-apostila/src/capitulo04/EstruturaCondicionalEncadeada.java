package capitulo04;

public class EstruturaCondicionalEncadeada {
	public static void main(String[] args) {
		int opcao = 1;
		
		if(opcao == 1) {
			System.out.println("Abrir a tela de novo cadastro");
		} else if(opcao == 2) {
			System.out.println("Abir a tela de edi��o de cadastro");
		} else if(opcao == 3) {
			System.out.println("Abrir a tela lista de cadastros");
		} else if(opcao == 4) {
			System.out.println("Abrir tela de relatorio");
		} else if(opcao == 5) {
			System.out.println("Abrir tela de exclus�o de cadastros");
		} else {
			System.out.println("Op��o inv�lida!");
		}
		
		switch(opcao) {
		case 1 :
			System.out.println("Abrir a tela de novo cadastro");
			break;
		case 2 :
			System.out.println("Abir a tela de edi��o de cadastro");
			break;
		case 3 :
			System.out.println("Abrir a tela lista de cadastros");
			break;
		case 4 :
			System.out.println("Abrir tela de relatorio");
			break;
		case 5 :
			System.out.println("Abrir tela de exclus�o de cadastros");
			break;
		default:
			System.out.println("Op��o inv�lida!");
		}
		
		String pais = "Brasil";
		
		switch(pais) {
		case "Brasil" : 
		case "Portugal" :
			System.out.println("Bom dia");
			break;
		case "Argentina" :
		case "Mexico" :
			System.out.println("Buenos dias");
			break;
		case "Fran�a" :
			System.out.println("Bon jour");
			break;
		case "Inglaterra" :
			System.out.println("Good morning");
			break;
		default :
			System.out.println("Good morning!");
		}
		

	}
}
