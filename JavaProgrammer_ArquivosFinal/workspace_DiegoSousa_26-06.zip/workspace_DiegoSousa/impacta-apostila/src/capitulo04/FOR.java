package capitulo04;

public class FOR {
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println("Boa noite! - " + i);
		}
		
		
		for(int i = 0; i < 6; i++) {
			System.out.println("Itera��o - " + i);
			for(int j = 0; j < 3; j++) {
				System.out.println("\tItera��o Interna - " + j);
			}
		}

	}
}
