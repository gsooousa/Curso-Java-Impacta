package capitulo04;

public class ExemploOutrosComandos {
	public static void main(String[] args) {
		String aluno = "";
		
		exibirAlunos:
		for(int i = 0; i < 12; i++) {
			if(i == 7) {
				continue exibirAlunos;
			} else {
				aluno = "Aluno - " + i;
				System.out.println(aluno);
			}
		}
		
		principal:
			for (int i = 0; i < 6; i++) {
				System.out.println("Estou passando no for principal - " +  i);
				for (int j = 0; j < 3; j++) {
					if (j == 1) {
						break principal;
					}
					System.out.println("\tPasei aqui antes de encerrar o for interno - " + j);
				}
			}
		
	}
}
