package capitulo04;

public class EstruturaCondicionalSimples {
	public static void main(String[] args) {
		int a = 5, b = 3, c = 12;
		
		if(a > 3) {
			System.out.println("O valor de a \"" + a + "\" � maior do que 3");
		}
		
		if(b == 6) {
			System.out.println("O valor de b � igual a 6");
		} else {
			System.out.println("O valor de b n�o � igual a 6");
		}
		
		switch(c) {
		case 5:
			System.out.println("O n�mero � 5");
			break;
		default:
			System.out.println("O numero n�o � 5");
		}
	}
}
