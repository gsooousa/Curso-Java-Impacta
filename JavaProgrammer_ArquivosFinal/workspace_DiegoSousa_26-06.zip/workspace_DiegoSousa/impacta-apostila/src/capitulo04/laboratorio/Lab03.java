package capitulo04.laboratorio;

public class Lab03 {
	public static void main(String[] args) {
		for(int ano = 1930; ano <= 2019; ano+=4) { // ano = ano + 4
			if(ano == 1942 || ano == 1946) { 
				continue;
			} 
			System.out.println("Copa do mundo  de " + ano);
		}
	}
}
