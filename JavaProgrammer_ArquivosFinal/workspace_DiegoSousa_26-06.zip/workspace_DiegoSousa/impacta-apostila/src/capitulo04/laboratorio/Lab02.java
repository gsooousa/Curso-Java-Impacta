package capitulo04.laboratorio;

import java.util.Scanner;

public class Lab02 {
	public static void main(String[] args) {
		String mes, msgpadrao = "O m�s escolhido tem ";
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Descubra quantos dias tem o m�s escolhido:");
		System.out.print("Digite um m�s: ");
		mes = scan.next().toLowerCase();
		
		switch(mes) {
		case "janeiro" :
		case "marco" :
		case "mar�o" :
		case "maio" :
		case "julho" :
		case "agosto" :
		case "outubro" :
		case "dezembro" :
			System.out.println(msgpadrao + "31 dias");
			break;
			
		case "fevereiro" :
			System.out.println("Digite o ano desejado: ");
			int ano = scan.nextInt();
			boolean bissexto = ano % 4 == 0 && ano % 100 != 0 || ano % 400 == 0;
			System.out.println(bissexto ? msgpadrao + "29 dias (Bissexto)" : msgpadrao + "28 dias");
			
//			if(ano % 4 == 0 && ano % 100 != 0 || ano % 400 == 0) {
//				System.out.println(msgpadrao + "29 dias (Bissexto)");
//			} else {
//				System.out.println(msgpadrao + "28 dias");
//			}
			break;
	
		case "abril" :
		case "junho" :
		case "setembro" :
		case "novembro" :
			System.out.println(msgpadrao + "30 dias");
			break;
			
		default :
			System.out.println("O m�s escolhido n�o existe!");
		}
		
		scan.close();
		
	}
}
