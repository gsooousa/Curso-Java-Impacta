package capitulo04.laboratorio;

public class Lab04 {
	public static void main(String[] args) {
		//TODO EXIBIR A TABUADA DE ACORDO COM A ESCOLHA DO USU�RIO
		//TODO 2 X 2 = 4
	}
}
