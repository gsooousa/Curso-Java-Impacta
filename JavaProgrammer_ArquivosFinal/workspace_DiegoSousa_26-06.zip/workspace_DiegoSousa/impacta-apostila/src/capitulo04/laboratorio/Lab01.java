package capitulo04.laboratorio;

import java.util.Scanner;

public class Lab01 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		final int numero; // ARMAZENA O NUMERO DIGITADO PELO USUARIO
		int cont = 2; // ARMAZENA A QTDE DE DIVISOES EXATAS (RESTO IGUAL A ZERO)
		
		System.out.print("Digite um numero para verificar se � primo: ");
		numero = scan.nextInt();
		scan.close();
		
		for(int i = 2; i < numero; i++) {
			if(numero % i == 0) {
				cont++; // AUMENTA O VALOR DE CONT ATRIBUINDO QUE HOUVE MAIS UMA DIVIS�O EXATA
			}
		}
		
		System.out.println(cont == 2 ? "Numero primo!" : "N�o � um numero primo!");
	}
}
