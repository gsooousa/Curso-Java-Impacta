package capitulo04;

public class DoWhile {
	public static void main(String[] args) {
		int a = 12;
		while(a < 10) {
			System.out.println(a + " Ainda � menor que 10");
			a++;
		}
		
		System.out.println("\n ------------------- \n");
		
		int b = 12;
		do {
			System.out.println(b + " Ainda � menor que 10");
			b++;
		} while(b < 10);
	}
}
