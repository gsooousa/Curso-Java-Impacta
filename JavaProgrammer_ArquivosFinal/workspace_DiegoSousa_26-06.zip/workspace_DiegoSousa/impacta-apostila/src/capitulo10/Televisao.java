package capitulo10;

public class Televisao implements Eletrodomestico {

	@Override
	public void ligar() {
		System.out.println("Televis�o Ligando..");
	}

	@Override
	public void desligar() {
		System.out.println("Televis�o Desligando..");
	}

}
