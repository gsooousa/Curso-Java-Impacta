package capitulo10.laboratorio;

public class Grafico implements Imprimivel {

	@Override
	public void imprimir() {
		System.out.println("Gr�fico sendo impresso!");
	}

}
