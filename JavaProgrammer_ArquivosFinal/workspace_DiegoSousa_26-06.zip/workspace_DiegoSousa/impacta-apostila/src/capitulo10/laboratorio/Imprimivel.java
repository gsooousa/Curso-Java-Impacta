package capitulo10.laboratorio;

public interface Imprimivel {
	void imprimir();
}
