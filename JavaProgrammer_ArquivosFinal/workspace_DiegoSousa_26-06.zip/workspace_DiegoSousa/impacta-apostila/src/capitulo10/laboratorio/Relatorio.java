package capitulo10.laboratorio;

public class Relatorio implements Imprimivel {

	@Override
	public void imprimir() {
		System.out.println("Relat�rio sendo impresso");
	}

}
