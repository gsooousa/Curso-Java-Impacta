package capitulo10;

public class Executando {
	public static void main(String[] args) {
		Eletrodomestico eletro;
		eletro = new Geladeira();
		eletro.ligar();
		
		Eletrodomestico geladeira, televisao, microondas;
		geladeira = new Geladeira();
		televisao = new Televisao();
		microondas = new Microondas();
		
		geladeira.ligar();
		geladeira.desligar();
		
		televisao.ligar();
		televisao.desligar();
		
		microondas.ligar();
		microondas.desligar();
		
		System.out.println("\nUsando o m�todo static da interface Eletrodomestico");
		Eletrodomestico.ligarTudo(microondas, geladeira, televisao);
		
		System.out.println("\n\nUsando o m�todo default acionarTimer de Eletrodomestico");
		televisao.ligar();
		televisao.acionarTimer(1);
	}
}
