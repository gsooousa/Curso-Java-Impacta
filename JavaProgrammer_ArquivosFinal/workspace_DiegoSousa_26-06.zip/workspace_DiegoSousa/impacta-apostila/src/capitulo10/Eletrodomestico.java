package capitulo10;

public interface Eletrodomestico {
	public static final String descricao ="XPTO";
	
	// NESSES DOIS TEMOS A MESMA APLICACAO (PUBLIC ABSTRACT ....)
	void ligar();
	public abstract void desligar();
	
	static void ligarTudo(Eletrodomestico ... eletros) {
		for (Eletrodomestico eletro : eletros) {
			eletro.ligar();
		}
	}
	
	//QUANDO N�O DEFINIDO DE OUTRA MANEIRA O ACESSO � PUBLICO
	default void acionarTimer(int minutos) {
		try { 
			Thread.sleep(minutos * 60000); 
		} catch (Exception e) {
			
		}
		desligar();
	}
	
	
	
	@SuppressWarnings("unused")
	private void meuMetodoPrivado() {
		System.out.println("Metodo Privado");
	}
	
}
