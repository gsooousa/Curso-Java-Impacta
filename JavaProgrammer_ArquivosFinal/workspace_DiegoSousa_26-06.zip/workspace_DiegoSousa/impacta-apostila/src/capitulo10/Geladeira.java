package capitulo10;

public class Geladeira implements Eletrodomestico {

	@Override
	public void ligar() {
		System.out.println("Geladeira Ligando... ");
	}

	@Override
	public void desligar() {
		System.out.println("Geladeira Desligando... ");
	}
	
	public String teste(String x) {
		return "";
	}

}
