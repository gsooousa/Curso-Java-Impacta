package capitulo10;

public class Microondas implements Eletrodomestico {

	@Override
	public void ligar() {
		System.out.println("Microondas Ligando...");
	}

	@Override
	public void desligar() {
		System.out.println("Microondas Desligando... ");
	}

}
