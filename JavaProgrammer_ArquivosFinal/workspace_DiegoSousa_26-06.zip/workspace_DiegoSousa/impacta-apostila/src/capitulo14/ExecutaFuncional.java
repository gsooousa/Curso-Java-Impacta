package capitulo14;

public class ExecutaFuncional {
	public static void main(String[] args) {
		ExemploFuncional01 ex01 = () -> System.out.println("Hello World!!!");
		ex01.exibir();
		
		ExemploFuncional02 ex02 = (x) -> System.out.println("Nome: " + x);
		ex02.exibir("Diego Sousa");
		
		ExemploFuncional03 ex03 = (x,y) -> System.out.println("Nome: " + x + ", Idade: " + y);
		ex03.exibir("Diego Sousa", 31);
		
		ExemploFuncional04 ex04 = (x, y, z) -> ((x+y+z)/3);
		System.out.printf("%.1f\n", ex04.media(5.5, 7.3, 9.2));
		
		ExemploFuncional04 ex05 = (x, y, z) -> {
			double soma = x + y + z;
			double media = soma / 3;
			
			return media;
		};
		System.out.printf("%.2f",ex05.media(3.5, 7.8, 9.6));
		
		
		
	}
}
