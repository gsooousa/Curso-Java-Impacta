package capitulo14;

public class Executando {
	public static void main(String[] args) {
		
		//IMPLEMENTA��O TRADICIONAL
		Soma soma = new Soma();
		System.out.println("Soma(Tradicional): " +soma.execute(7, 12));
		
		//IMPLEMENTA��O CLASSE ANONIMA
		OperacaoAritmetica operacaoSoma = new OperacaoAritmetica() {
			
			@Override
			public double execute(double value1, double value2) {
				
				return (value1 + value2);
			}
		};
		System.out.println("Soma(Classe an�nima): " +operacaoSoma.execute(8, 16));
		
		//IMPLEMENTA��O FUNCIONAL
		OperacaoAritmetica operacaoSubtracao = (x, y) -> x - y;
		System.out.println("Subtra��o(Funcional): " +operacaoSubtracao.execute(10, 5));
		
		OperacaoAritmetica operacao;
		operacao = (x,y) -> x*y;
		System.out.println("Multiplica��o(Funcional): " + operacao.execute(10, 10));
		//----------------
		operacao = (x,y) -> Math.pow(x, y);
		System.out.println("Exponencia��o(Funcional): " +operacao.execute(2, 3));
		
		
		
	}
}
