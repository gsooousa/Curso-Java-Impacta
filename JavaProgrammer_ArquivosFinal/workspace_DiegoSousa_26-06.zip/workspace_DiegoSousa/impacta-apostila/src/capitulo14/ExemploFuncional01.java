package capitulo14;

@FunctionalInterface
public interface ExemploFuncional01 {
	void exibir();
	
}
