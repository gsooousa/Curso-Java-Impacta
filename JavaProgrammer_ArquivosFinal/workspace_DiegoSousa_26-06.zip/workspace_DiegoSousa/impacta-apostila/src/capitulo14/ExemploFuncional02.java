package capitulo14;

public interface ExemploFuncional02 {
	void exibir(String text);
}
