package capitulo14;

public interface ExemploFuncional04 {
	double media(double num1, double num2, double num3);
}
