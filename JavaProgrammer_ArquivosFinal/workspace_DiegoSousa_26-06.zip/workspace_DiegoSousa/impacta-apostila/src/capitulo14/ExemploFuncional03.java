package capitulo14;

public interface ExemploFuncional03 {
	void exibir(String text, int number);
}
