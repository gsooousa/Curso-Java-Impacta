package capitulo14;

@FunctionalInterface
public interface OperacaoAritmetica {
	double execute(double value1, double value2);
	
}
