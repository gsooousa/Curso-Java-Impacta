package capitulo14;

public class ExemploReferenciaMetodo {
	public static void main(String[] args) {
		OperacaoAritmetica funcao = FinancialUtils::calculaJuros;
		System.out.println(funcao.execute(1000, 10));
		
		Produto produto = new Produto(null, 0);
		OperacaoAritmetica funcaoProduto = produto::aumentarPreco;
		System.out.println(funcaoProduto.execute(500, 10));
		
	}
}
