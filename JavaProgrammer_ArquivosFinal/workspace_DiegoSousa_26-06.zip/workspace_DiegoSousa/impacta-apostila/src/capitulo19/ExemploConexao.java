package capitulo19;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ExemploConexao {
	public static void main(String[] args) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aluo", "impacta", "impacta");
			System.out.println("Conex�o estabelecida com sucesso!");
			conn.close();
		} catch (SQLException e) {
			System.out.println("Problemas ao estabeleer conex�o!");
			System.out.println(e.getMessage());
		}
	}
}
