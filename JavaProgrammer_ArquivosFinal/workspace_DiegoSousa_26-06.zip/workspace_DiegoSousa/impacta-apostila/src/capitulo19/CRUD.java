package capitulo19;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CRUD {
	public static final String url = "jdbc:mysql://localhost:3306/aluno";
	public static final String user = "impacta";
	public static final String password = "impacta";
	
	
	public static void main(String[] args) {
		//inserirRegistro();
		//inserirRegistro("Mauricio", "Spring MVC", 7780.52);
		//atualizarRegistro();
		//atualizarRegistro(6, "Arthur", "PHP", 321.56);
		//deletarRegistro();
		//deletarRegistro(7);
		selecionarRegistros();
	}
	
	public static void selecionarRegistros() {
		String query = "SELECT * FROM aluno";
		Connection conn = abrirConexao();
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				System.out.printf("%d - %s %s %.2f\n",
									rs.getInt("idaluno"),
									rs.getString("nome"), 
									rs.getString("curso") , 
									rs.getDouble("mensalidade"));
			}
			System.out.println("Registros selecionados com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao selecionar registros: " + e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}

	public static void deletarRegistro(int id) {
		String query = "DELETE FROM aluno WHERE idaluno = ?";
		Connection conn = abrirConexao();
		try {
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setInt(1, id);
			pst.execute();
			System.out.println("Registro deletado com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao deletar registro: " +  e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}
	
	public static void deletarRegistro() {
		String query = "DELETE FROM aluno WHERE idaluno = 1";
		Connection conn = abrirConexao();
		try {
			Statement st = conn.createStatement();
			st.execute(query);
			System.out.println("Registro deletado com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao deletar registro: " +  e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}

	public static void atualizarRegistro(int id, String nome, String curso, double mensalidade) {
		String query = "UPDATE aluno SET nome = ?, curso = ?, mensalidade = ? WHERE idaluno = ?";
		Connection conn = abrirConexao();
		try {
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, nome);
			pst.setString(2, curso);
			pst.setDouble(3, mensalidade);
			pst.setInt(4, id);
			pst.execute();
			System.out.println("Registro atualizado com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao atualizar registro: " + e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}
	
	public static void atualizarRegistro() {
		String query = "UPDATE aluno SET nome = 'Anderson', curso = 'C#', mensalidade = 658.45 WHERE idaluno = 4";
		Connection conn = abrirConexao();
		try {
			Statement st = conn.createStatement();
			st.execute(query);
			System.out.println("Registro atualizado com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao atualizar registro: " + e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}

	public static void inserirRegistro(String nome, String curso, double mensalidade) {
		String query = "INSERT INTO aluno (nome, curso, mensalidade) VALUES (?, ?, ?)";
		Connection conn = abrirConexao();
		try {
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, nome);
			pst.setString(2, curso);
			pst.setDouble(3, mensalidade);
			pst.execute();
			System.out.println("Registro inserido com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao inserir: " + e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}
	
	public static void inserirRegistro() {
		String query = "INSERT INTO aluno (nome, curso, mensalidade) VALUES ('Sara', 'Java', 1358.75)";
		Connection conn = abrirConexao();
		try {
			Statement st = conn.createStatement();
			st.execute(query);
			System.out.println("Registro inserido com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro ao inserir: " + e.getMessage());
		} finally {
			fecharConexao(conn);
		}
	}
	
	public static Connection abrirConexao() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, password);
			System.out.println("Conex�o estabelecida com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro: " + e.getMessage());
		}
		return conn;
	}
	
	public static void fecharConexao(Connection conn) {
		try {
			conn.close();
			System.out.println("Conex�o fechada com sucesso!");
		} catch (SQLException e) {
			System.out.println("Erro : " + e.getMessage());
		}
	}
}
