package capitulo15;

import java.util.LinkedList;
import java.util.List;

public class ExemploList {
	public static void main(String[] args) {
		List<String> listaAlunos = new LinkedList<>();
		
		listaAlunos.add("Andr�");
		listaAlunos.add("Guilherme");
		listaAlunos.add("Guilherme");
		listaAlunos.add("Guilherme");
		listaAlunos.add("Guilherme");
		
		listaAlunos.add("Ericson");
		listaAlunos.add("Anderson");
		listaAlunos.add("Alcyr");
		listaAlunos.add("Arthur");
		listaAlunos.add("Caike");
		listaAlunos.add("Gustavo");
		listaAlunos.add("Sara");
		listaAlunos.add("Mauricio");
		listaAlunos.add("Jefferson");
		
		System.out.println(listaAlunos);
		System.out.println("Tamanho da lista: " + listaAlunos.size());
		System.out.println("Primeiro elemento da lista: " +  listaAlunos.get(0));
		System.out.println("Ultimo elemento da lista: " + listaAlunos.get(listaAlunos.size()-1));
		listaAlunos.add(0, "Diego");
		System.out.println(listaAlunos.get(0));
		
		System.out.println("A lista esta vazia? " + listaAlunos.isEmpty());
		listaAlunos.remove("Arthur");
		System.out.println("**************************************\nStream - sorted");
		listaAlunos.stream().sorted().forEach(p->System.out.println(p));
		System.out.println("**************************************");
		listaAlunos.sort((p1,p2) -> p1.compareTo(p2));
		listaAlunos.replaceAll(p -> p.toUpperCase());
		listaAlunos.forEach(x -> System.out.println(listaAlunos.indexOf(x) + "- " + x));
		System.out.println("**************************************");
		System.out.println("O Alcyr esta na lista? " + listaAlunos.contains("Arthur"));
		//listaAlunos.clear();
		listaAlunos.removeIf(p -> p.equals("Gustavo".toUpperCase()));
		System.out.println("Tamanho da lista: " + listaAlunos.size());
		listaAlunos.forEach(x -> System.out.println(listaAlunos.indexOf(x) + "- " + x));
		
	}
}
