package capitulo15;

public class Carro implements Comparable<Carro>{
	private String modelo;
	private String placa;
	
	public Carro(String modelo, String placa) {
		this.modelo = modelo;
		this.placa = placa;
	}
	
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}

	@Override
	public int compareTo(Carro outroCarro) {
			if(this.modelo.length() > outroCarro.modelo.length()) {
				return 1;
			} else if(this.modelo.length() < outroCarro.modelo.length()) {
				return -1;
			} else {
				return 0;
			}
	}
	
	@Override
	public String toString() {
		return this.modelo + ", " + this.placa;
	}
}
