package capitulo15;

import java.util.Set;
import java.util.TreeSet;

public class ExemploSet {
	public static void main(String[] args) {
//		Set<String> listaAlunos = new TreeSet<>();
//		listaAlunos.add("Andr�");
//		listaAlunos.add("Guilherme");
//		listaAlunos.add("Guilherme");
//		listaAlunos.add("Guilherme");
//		listaAlunos.add("Guilherme");
//		
//		listaAlunos.add("Ericson");
//		listaAlunos.add("Anderson");
//		listaAlunos.add("Alcyr");
//		listaAlunos.add("Arthur");
//		listaAlunos.add("Caike");
//		listaAlunos.add("Gustavo");
//		listaAlunos.add("Sara");
//		listaAlunos.add("Mauricio");
//		listaAlunos.add("Jefferson");
//		
//		System.out.println(listaAlunos.size());
//		listaAlunos.forEach(p -> System.out.println(p));
		
		Set<Carro> carros = new TreeSet<>();
		carros.add(new Carro("Jetta", "DSF8547"));
		carros.add(new Carro("Q3", "ASF8547"));
		carros.add(new Carro("Golf", "HER9865"));
		carros.add(new Carro("Renegade", "ABC2255"));
		
		carros.forEach(System.out::println);
	}
}
