package capitulo09;

public class Pessoa {
	String nome;
	int idade;
	char sexo;
	
	public Pessoa(String nome, int idade, char sexo) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.sexo = sexo;
	}
}
