package capitulo09;

public class HerancaApp {
	public static void main(String[] args) {
		Atleta obj = new Atleta("Andr�", 26, 'M', "Empinador de pipa");
		obj.exibirInformacoes();
	}
}
