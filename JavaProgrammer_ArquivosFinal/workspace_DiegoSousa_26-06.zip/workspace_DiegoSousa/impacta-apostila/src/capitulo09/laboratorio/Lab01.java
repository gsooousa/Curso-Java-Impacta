package capitulo09.laboratorio;

public class Lab01 {
	public static void main(String[] args) {
		Pessoa rafael, manuel, claudia;
		rafael = new Professor("Rafael", 38, 'M', 261454789, "05/02/1974", 2500F, "Portugu�s");
		manuel = new Aluno("Manuel", 19, 'M', 521234567, "15/06/1993", 1099F, "Ci�ncia da computa��o");
		claudia = new Aluno("Claudia", 22, 'F', 415678912, "12/08/1990", 799F, "Administra��o");
		
		rafael.falar("Manuel?");
		manuel.falar("Presente!");
		rafael.falar("Claudia?");
		claudia.falar("Presente!");
		
		rafael.mostrarDados();
		manuel.mostrarDados();
		claudia.mostrarDados();
	}
}
