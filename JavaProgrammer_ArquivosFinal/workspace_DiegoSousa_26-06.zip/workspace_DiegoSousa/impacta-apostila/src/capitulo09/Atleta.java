package capitulo09;

public class Atleta extends Pessoa {
	String tipoEsporte;
	
	public Atleta(String nome, int idade, char sexo, String tipoEsporte) {
		super(nome, idade, sexo);
		this.tipoEsporte = tipoEsporte;
	}
	
	public void exibirInformacoes() {
		System.out.println(nome);
		System.out.println(idade);
		System.out.println(sexo);
		System.out.println(tipoEsporte);
	}
}
