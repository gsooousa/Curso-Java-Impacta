package capitulo02;

public class TiposDados02 {
	public static void main(String[] args) {
		int valDecimal = 64;
		int valBinario = 0b1000000;
		int valHexadecimal = 0x40;
		int valOctal = 0100;
		long valLong = 150_025_000_251_000L;
		
		System.out.println("valDecimal = " + valDecimal);
		System.out.println("valBinario = " +  valBinario);
		System.out.println("valHexadecimal = " + valHexadecimal);
		System.out.println("valOctal = " + valOctal);
		System.out.println("valLong = " + valLong);
	}
}
