package capitulo02;

public class Wrappers {
	public static void main(String[] args) {
		Integer number01 = 15;
		String numberText = number01.toString();
		
		System.out.println("Abaixo vai um valor:");
		System.out.println();
		System.out.println(numberText);
	}
}
