package capitulo02;

public enum DiaDaSemana {
	SEGUNDA("Segunda-Feira"),
	TERCA("Ter�a-Feira"),
	QUARTA("Quarta-Feira"),
	QUINTA("Quinta-Feira"),
	SEXTA("Sexta-Feira"),
	SABADO("Sabado"),
	DOMINGO("Domingo");
	
	String desc;
	
	private DiaDaSemana(String descricao) {
		this.desc = descricao;
	}
	
	@Override
	public String toString() {
		return this.desc;
	}
}
