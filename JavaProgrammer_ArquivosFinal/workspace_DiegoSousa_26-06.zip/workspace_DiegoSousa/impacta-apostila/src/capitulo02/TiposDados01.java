package capitulo02;

public class TiposDados01 {
	public static void main(String[] args) {
		//	TIPOS PRIMITIVOS INTEIROS
		byte v1 = 120;
		short v2 = 1024;
		int v3 = 2048;
		long v4 = 12580;
		
		// TIPOS PRIMITIVOS PONTO FLUTUANTE
		float v5 = 13.8F;
		double v6 = 125.9;
		
		// TIPOS LOGICOS
		boolean v7 = true;
		boolean v8 = false;
		
		// TIPOS TEXTUAIS
		char v9 = 65;
		char v10 = '\u0041';
		char v11 = 'A';
		
		// EXIBINDO OS VALORES INSERIDOS NAS VARIAVEIS
		System.out.println("(byte) v1 = " +  v1);
		System.out.println("(short) v2 = " + v2 );
		System.out.println("(int) v3 = " + v3);
		System.out.println("(long) v4 = " + v4);
		System.out.println("(float) v5 = " + v5);
		System.out.println("(double) v6 = " + v6);
		System.out.println("(boolean) v7 = " + v7);
		System.out.println("(boolean) v8 = " +  v8);
		System.out.println("(char) v9 = " + v9);
		System.out.println("(char) v10 = " + v10);
		System.out.println("(char) v11 = " + v11);
	}
}
