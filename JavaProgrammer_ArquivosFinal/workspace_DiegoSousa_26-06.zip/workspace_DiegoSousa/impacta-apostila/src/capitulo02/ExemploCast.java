package capitulo02;

public class ExemploCast {
	public static void main(String[] args) {
		int a = 1;
		byte b = 0;
		int c = 0;
		double d = 128505845547554448445.66;
		char teste = 'a';
		String number = "10";
				
		
		b = (byte) a;
		System.out.println(b);
		
		c = (int) d;
		System.out.println(c);
		
		System.out.println(teste);
		System.out.println(number);
	}
}
