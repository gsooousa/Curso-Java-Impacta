package capitulo02;

public class ExemploFinal {
	public static void main(String[] args) {
		final float salarioFuncionario = 12580.80F;
		//salarioFuncionario = 1280.65;
		// N�O � POSSIVEL ALTERAR O VALOR DE UMA VARI�VEL QUE FOI DEFINIDA COMO FINAL
		
		final int idade;
		idade = 31;
		
		System.out.println(salarioFuncionario);
		System.out.println(idade);
		
		System.out.println(Math.PI);
		System.out.println(DiaDaSemana.QUINTA);
	}
}
