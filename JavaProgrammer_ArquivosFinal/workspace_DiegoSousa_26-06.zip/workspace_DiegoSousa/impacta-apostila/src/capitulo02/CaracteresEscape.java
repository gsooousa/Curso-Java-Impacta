package capitulo02;

public class CaracteresEscape {
	public static void main(String[] args) {
		String texto;
		
		/*
		 * Treinamento: Java Programmer
		 * Local: Impacta Tecnologia
		 * Data: 20/05 a 24/06
		 * Periodo: Noturno
		 * 
		 */
		texto = "Treinamento: \"Java\" Programmer\n"
				+ "Local: Impacta Tecnologia\n"
				+ "Data: 20/05 a 24/06\n"
				+ "Periodo: Noturno";
		System.out.println(texto);
		
		System.out.println("\n\nTreinamento: Java Programmer\n"
				+ "Local: Impacta Tecnologia\n"
				+ "Data: 20/05 a 24/06\n"
				+ "Periodo: Noturno");
	}
}
