package capitulo11;

public class ExceptionVerificadas {
	public static void main(String[] args) {
		String[] nomes = new String[2];
		
		// EXCEPTION N�O VERIFICADA (COMPILADOR N�O APRESENTA ERRO AO ESCREVER UM 
		// ACESSO AO INDICE INVALIDO (RUNTIME)
		nomes[0] = "Diego";
		nomes[1] = "Danilo";
		//nomes[2] = "Douglas";
		
		// EXCEPTION VERIFICADA, O M�TODO UTILIZADO ELE FOI MARCADO COMO PERIGOSO A LAN�AR EXCEPTION
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("Ufaaaa!");
	}
}
