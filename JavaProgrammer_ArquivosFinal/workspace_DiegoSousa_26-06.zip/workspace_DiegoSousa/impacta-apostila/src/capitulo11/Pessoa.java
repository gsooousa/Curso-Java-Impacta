package capitulo11;

public abstract class Pessoa {
	public abstract void falar();
}
