package capitulo11.laboratorio;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ExercicioGravacao {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Digite uma frase: ");
		String texto = scan.nextLine();
		
		try {
			PrintWriter writer = new PrintWriter("doc1.txt");
			writer.println(texto);
			writer.close();
			System.out.println("Arquivo gravado com sucesso!");
		} catch(IOException e) {
			System.out.println("Falha ao gravar informa��es!");
			System.out.println(e.getMessage());
		} finally {
			scan.close();
		}
	}
}
