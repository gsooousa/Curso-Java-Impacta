package capitulo11.laboratorio;

import java.util.Scanner;

public class ExercicioIdade {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		try {
			System.out.print("Digite o ano de seu nascimento: ");
			String anoText = scan.nextLine();
			int anoNascimento = Integer.parseInt(anoText);
		
			int idade = 2019 - anoNascimento;
			System.out.println("Sua idade �: " + idade);
		} catch(NumberFormatException e) {
			System.out.println("Valor digitado inv�lido");
		} finally {
			scan.close();
		}
	}
}
