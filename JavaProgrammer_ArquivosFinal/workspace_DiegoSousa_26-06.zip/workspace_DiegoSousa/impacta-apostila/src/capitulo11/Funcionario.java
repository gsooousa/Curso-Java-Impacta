package capitulo11;

public abstract class Funcionario extends Pessoa {
	public abstract void trabalhar();
}
