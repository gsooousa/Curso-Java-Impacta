package capitulo11;

import java.util.Scanner;

public class ExemploTryCatch02 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String nome;
		int idade;
		
		try {
			System.out.println("Digite o seu nome: ");
			nome = scan.nextLine();
			
			System.out.println("Digite a sua idade: ");
			idade = Integer.parseInt(scan.nextLine());
			
			System.out.println("Nome: " + nome);
			System.out.println("Idade: " + idade);
		} catch (NumberFormatException | NullPointerException | ArithmeticException e) {
			System.out.println("Oops.. Voc� digitou um valor n�o esperado para idade!");
		} finally {
			System.out.println("Passou no finally");
			scan.close();
		}
	}
}
