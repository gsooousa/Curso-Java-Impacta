package capitulo11;

public class AdicionarProdutoException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public AdicionarProdutoException() {
		super();
	}
	
	public AdicionarProdutoException(String texto) {
		super(texto);
	}
	
	public AdicionarProdutoException(String texto, Throwable motivo) {
		super(texto, motivo);
	}
	
	public AdicionarProdutoException(Throwable motivo) {
		super(motivo);
	}
	
}
