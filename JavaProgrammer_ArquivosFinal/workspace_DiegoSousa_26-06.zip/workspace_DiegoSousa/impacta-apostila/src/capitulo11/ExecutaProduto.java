package capitulo11;

public class ExecutaProduto {
	public static void main(String[] args) {
		Carrinho c = new Carrinho();
		try {
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
			c.adicionarProduto(new Produto("Heinken 330ML", 3.49));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println(c.fecharPedido());
		
	}
}
