package capitulo11;

public class ExemploTryCatch {
	public static void main(String[] args) {
		// SIMPLES
		try {
			int i = 0;
			i = 1 / 0;
			System.out.println(i);
		} catch (Exception e) {
			System.out.println("Falha ao dividir os valores!\nErro: " + e.getMessage());
		}
		
		// MULTIPLO
		try {
			int i = 0;
			i = 1 / 0;
			System.out.println(i);
		} catch(ArithmeticException e) {
			System.out.println("Falha ao dividir os valores!\nErro: " + e.getMessage());
		} catch (NullPointerException e) {
			System.out.println("Objetos utilizados est�o nulos!\nErro: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Erro desconhecido!\nMSG: " + e.getMessage());
		}
		
		
	}
}
