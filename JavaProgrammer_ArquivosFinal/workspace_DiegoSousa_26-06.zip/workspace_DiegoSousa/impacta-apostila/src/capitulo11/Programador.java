package capitulo11;

public class Programador extends Funcionario {

	@Override
	public void trabalhar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void falar() {
		// TODO Auto-generated method stub
		
	}
	
}
