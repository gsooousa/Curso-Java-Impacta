package capitulo11;

public class Carrinho {
	final int limite = 10; 
	Produto[] listaProdutos;
	static int indice;

	public Carrinho() {
		this.listaProdutos = new Produto[limite];
	}
	
	public Produto[] getListaProdutos() {
		return listaProdutos;
	}

	public void adicionarProduto(Produto produto) throws AdicionarProdutoException {
		if(indice < listaProdutos.length) {
			listaProdutos[indice] = produto;
			indice++;
			System.out.println("Produto - "+ produto.getDescricao() +", adicionado com sucesso!");
		} else {
			System.out.println("Voc� ja atingiu o limite de produtos");
			throw new AdicionarProdutoException("Erro ao adicionar produto no indice");
		}
		
	}
	
	public double fecharPedido() {
		double total = 0;
		for (Produto produto : listaProdutos) {
			total += produto.getPreco();
		}
		
		return total;
	}
}
