package capitulo07.laboratorio;

public class Lab01 {
	public static void main(String[] args) {
		Cadastro cad1 = new Cadastro();
		cad1.mostrar();
		
		System.out.println();
		
		Cadastro cad2 = new Cadastro("Claudio", "Abreu");
		cad2.mostrar();
		
		System.out.println();
		
		Cadastro cad3 = new Cadastro("Lourdes", "Souza", 40);
		cad3.mostrar();
	}
}
