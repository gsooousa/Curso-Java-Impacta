package capitulo07;

public class CriaCalcado {
	public static void main(String[] args) {
		Calcado ipanema = new Calcado("Azul", 39);
		System.out.println(ipanema.cor);
		System.out.println(ipanema.tamanho);
		
		Sandalia havaianas = new Sandalia("Havaianas", "Preta", 40);
		System.out.println(havaianas.marca);
		System.out.println(havaianas.cor);
		System.out.println(havaianas.tamanho);
	}
}
