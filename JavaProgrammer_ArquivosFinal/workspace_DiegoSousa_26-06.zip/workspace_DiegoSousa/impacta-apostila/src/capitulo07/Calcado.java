package capitulo07;

public class Calcado {
	String cor;
	int tamanho;
	
	public Calcado(String cor, int tamanho) {
		super();
		this.cor = cor;
		this.tamanho = tamanho;
	}
	
}
