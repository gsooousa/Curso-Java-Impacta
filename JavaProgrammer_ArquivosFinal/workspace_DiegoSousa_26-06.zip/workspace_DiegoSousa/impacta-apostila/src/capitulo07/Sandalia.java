package capitulo07;

public class Sandalia extends Calcado {
	String marca;
	
	public Sandalia(String marca, String cor, int tamanho) {
		super(cor, tamanho);
		this.marca = marca;
	}
}
