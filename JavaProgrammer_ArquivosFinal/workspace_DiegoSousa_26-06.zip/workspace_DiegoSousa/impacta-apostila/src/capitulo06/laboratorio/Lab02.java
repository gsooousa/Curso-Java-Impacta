package capitulo06.laboratorio;

import capitulo06.Calculadora;

public class Lab02 {
	public static void main(String[] args) {
		Calculadora calc = new Calculadora();
		
		System.out.println("M�todos subtrair sobrecarregados: ");
		System.out.println("Chamando a vers�o de subtrair com 2 double: " + calc.subtrair(4.5, 3.3));
		System.out.println("Chamando a vers�o de subtrair com 1 double e 1 int: " + calc.subtrair(6.3, 5));
		System.out.println("Chamando a vers�o de subtrair com 1 int e 1 double: " + calc.subtrair(7, 3.2));
	}
}
