package capitulo06;

import javax.swing.JOptionPane;

public class TesteThread {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Teste");
		
		System.out.println("Teste2");
	}
}
