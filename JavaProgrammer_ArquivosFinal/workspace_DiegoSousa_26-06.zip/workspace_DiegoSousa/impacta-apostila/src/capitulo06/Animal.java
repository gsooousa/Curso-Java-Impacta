package capitulo06;

public class Animal {
	String familia;
	
	
	public final void metodoAnimal() {
		System.out.println("Eu sou um animal!");
	}
}
