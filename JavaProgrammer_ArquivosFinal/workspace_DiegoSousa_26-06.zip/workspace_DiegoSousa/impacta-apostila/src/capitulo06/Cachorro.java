package capitulo06;

public class Cachorro extends Animal {
	private String raca;
	private String porte;
	private String nome;
	private int idade;
	
	public Cachorro() {
		super();
	}

	public Cachorro(String raca, String porte, String nome, int idade) {
		super();
		this.raca = raca;
		this.porte = porte;
		this.nome = nome;
		this.idade = idade;
	}

	public String getRaca() {
		return raca;
	}

	public void setRaca(String raca) {
		this.raca = raca;
	}

	public String getPorte() {
		return porte;
	}

	public void setPorte(String porte) {
		this.porte = porte;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	
//	@Override
//	public void metodoAnimal() {
//		System.out.println("Eu sou uma pessoa!");
//	}

	@Override
	public String toString() {
		return String.format("%s - %s, %d", getClass().getSimpleName(), getNome(), getIdade());
	}
}
