package capitulo06;

public class UsaCalculadora {
	public static void main(String[] args) {
		Calculadora calc = new Calculadora();
		
		int s = calc.somar(10, 20);
		
		System.out.println(s % 2 == 0 ? "Par" : "Impar");
		System.out.println("s = " + s);
	}
}
