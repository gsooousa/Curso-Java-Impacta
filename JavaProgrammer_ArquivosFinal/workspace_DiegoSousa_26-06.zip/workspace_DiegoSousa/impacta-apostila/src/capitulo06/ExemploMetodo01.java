package capitulo06;

public class ExemploMetodo01 {
	
	public int devolverValor() {
		int valor = 10;
		
		return valor;
	}
	
	public void apenasExecutar() {
		System.out.println("Rodou o m�todo");
	}
	
}
