package capitulo06;

public class Sobrecarga {
	
	public void exibirMensagem() {
		System.out.println("Ol� Visitante, seja bem bem vindo!");
	}
	
	public void exibirMensagem(String nome) {
		System.out.println("Ol� " +nome+ ", seja bem vindo!");
	}
	
	public void exibirMensagem(String nome, String tipoConta) {
		System.out.println("Ol� " +nome+" (Conta: " +tipoConta+"), seja bem vindo!");
	}
}
