package capitulo06;

public class MetodosApp {
	public static void main(String[] args) {
		ExemploMetodo01 obj = new ExemploMetodo01();
		
		int val = obj.devolverValor();
		System.out.println(val);
		
		obj.apenasExecutar();
		
		
		
	}
}
