package capitulo06;

public class ExecutandoMetodos {
	public static void main(String[] args) {
		Cachorro rex = new Cachorro("Poodle", "Pequeno", "Rex", 5);
		Cachorro spike = new Cachorro("Labrador", "Grande", "Spike", 9);
		Cachorro lady = new Cachorro("Golden", "Grande", "Lady", 4);
		Cachorro suzi = new Cachorro("Bulldog", "Pequeno", "Suzi", 3);
		Cachorro pit = new Cachorro("Pitbull", "Grande", "Pit", 11);
		
		
		
		ExemploVarArgs.exibirObjetos(rex, spike, lady, suzi, pit, rex, lady, suzi);
	}
}
