package capitulo06;

public class ExemploVarArgs {
	
	//MEMBRO DE CLASSE
	public static void exibirObjetos(Cachorro ... dogs) {
		for(Cachorro dog : dogs) {
			System.out.println(dog);
		}
	}
	
	//MEMBRO DE INSTANCIA
	public void teste() {
		
	}
	
}
