package capitulo06;

public class SobrecargaApp {
	public static void main(String[] args) {
		Sobrecarga obj = new Sobrecarga();
		obj.exibirMensagem();
		obj.exibirMensagem("Diego");
		obj.exibirMensagem("Diego", "Free");
	}
}
