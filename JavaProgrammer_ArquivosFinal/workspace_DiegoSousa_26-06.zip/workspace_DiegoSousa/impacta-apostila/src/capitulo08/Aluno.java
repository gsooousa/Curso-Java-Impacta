package capitulo08;

public class Aluno {
	String nome;
	
	@Override
	public String toString() {
		return "Aluno: " + nome;
	}
}
