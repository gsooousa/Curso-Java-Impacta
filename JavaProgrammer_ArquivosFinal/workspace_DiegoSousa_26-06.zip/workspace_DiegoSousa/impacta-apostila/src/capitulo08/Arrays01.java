package capitulo08;

import java.util.Scanner;

public class Arrays01 {
	public static void main(String[] args) {
		int[] numeros = new int[5];

		numeros[0] = 12;
		numeros[1] = 26;
		numeros[2] = 13;
		numeros[3] = 4;
		numeros[4] = 8;
		
		// ATRIBUTO LENGTH RETORNA O TAMANHO DA DEFINI��O DO ARRAY 
		System.out.println("Tamanho do array: " + numeros.length);
		
		System.out.println("Primeiro item do array: " + numeros[0]);
		
		System.out.println("Ultimo item do array: " + numeros[numeros.length-1]);
		
		System.out.println("--------- EXIBINDO TODOS OS VALORES DO ARRAY -----------");
		
		for(int i = 0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}

		Scanner scan = new Scanner(System.in);
		int[] idades = new int[4];
		for (int i = 0; i < idades.length; i++) {
			System.out.println("Digite uma idade: ");
			idades[i] = scan.nextInt();
		}
		
		scan.close();
		System.out.println("----- IMPRIMINDO TODAS AS IDADES DENTRO DO ARRAY ------");
		
		for (int i = 0; i < idades.length; i++) {
			System.out.println(idades[i]);
		}
		
	}
}
