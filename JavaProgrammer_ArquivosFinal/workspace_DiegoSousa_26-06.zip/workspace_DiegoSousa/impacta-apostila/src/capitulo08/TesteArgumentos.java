package capitulo08;

public class TesteArgumentos {
	public static void main(String[] args) {
		if (args.length > 0) {
			if(args[0].equals("cpf")) {
				System.out.println("Abrindo sistema de verifica��o pra Pessoa Fisica");
			} else if(args[0].equals("cnpj")){
				System.out.println("Abrindo sistema de verifica��o pra Pessoa Juridica");
			} else {
				System.out.println("Argumento n�o reconhecido. Tente cpf ou cnpj");
			}
		}
	}
}
