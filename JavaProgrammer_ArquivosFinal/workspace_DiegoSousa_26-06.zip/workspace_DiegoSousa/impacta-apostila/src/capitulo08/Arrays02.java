package capitulo08;

public class Arrays02 {
	public static void main(String[] args) {
		int[] notas = {8, 9, 10, 1};
		
		System.out.println(notas.length);
		System.out.println(notas[0]);
		System.out.println(notas[notas.length-1]);
	}
}
