package capitulo08.laboratorio;

public class Lab01 {
	
	public static int maiorNumero(int[] valores) {
		int maior = 0;
		for (int i = 0; i < valores.length; i++) {
			if(valores[i] > maior) {
				maior = valores[i];
			}
		}
		return maior;
		
//		Arrays.sort(valores);
//		return valores[valores.length-1];
	}
	
	public static void main(String[] args) {
		int[] numeros = {12, 5, 9, 45, 78, 4, 3, 2, 1};
		
		int maiorNumeroArray = Lab01.maiorNumero(numeros);
		System.out.println("Maior numero do array: " +  maiorNumeroArray);
	}
}
