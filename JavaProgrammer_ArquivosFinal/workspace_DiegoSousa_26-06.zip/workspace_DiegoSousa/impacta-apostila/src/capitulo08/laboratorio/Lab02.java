package capitulo08.laboratorio;

public class Lab02 {
	public static void main(String[] args) {
		if(args.length > 0) {
			int soma = 0;
			String idadeText = "";
			for(int i = 0; i < args.length; i++) {
				soma += Integer.parseInt(args[i]);
				idadeText += args[i] +  " ";
			}
			
			int media = soma / args.length;
			System.out.println("A m�dia das idades:");
			System.out.println(idadeText);
			System.out.println("� de: " + media + " anos.");
		} else {
			System.out.println("Entre com valores v�lidos para as idades");
		}
	}
}
