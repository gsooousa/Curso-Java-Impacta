package capitulo03;

public class OperadoresRelacionais {
	public static void main(String[] args) {
		int a = 10, b = 8;

		// MAIOR QUE
		System.out.println("a > b --> " + (a > b));
		// MENOR QUE
		System.out.println("a < b --> " + (a < b));
		// MAIOR OU IGUAL A
		System.out.println("a >= b --> " + (a >= b));
		// MENOR OU IGUAL A
		System.out.println("a <= b --> " + (a <= b));
		// IGUAL A
		System.out.println("a == b --> " + (a == b));
		// DIFERENTE DE 
		System.out.println("a != b --> " + (a != b));
	}
}
