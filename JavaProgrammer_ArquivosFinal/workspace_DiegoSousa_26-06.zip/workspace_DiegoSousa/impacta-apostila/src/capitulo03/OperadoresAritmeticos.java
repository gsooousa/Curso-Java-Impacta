package capitulo03;

public class OperadoresAritmeticos {
	public static void main(String[] args) {
		int a, b;
		
		a = 10;
		b = 3;
		
		System.out.println("Valor de a = " + a + " | Valor de b = " + b);
		System.out.println("Soma = " + (a + b));
		System.out.println("Subtra��o = " + (a - b));
		System.out.println("Multiplica��o = " + (a * b));
		System.out.println("Divis�o = "  + ((float)a / b));
		System.out.println("Divis�o = "  + (a / b));
		System.out.println("Resto da divis�o = " + (a % b));
		System.out.println("Exponencia��o = " + Math.pow(a, b));
		System.out.println("Radicia��o = " +  Math.sqrt((a + b)+3));
	}
}
