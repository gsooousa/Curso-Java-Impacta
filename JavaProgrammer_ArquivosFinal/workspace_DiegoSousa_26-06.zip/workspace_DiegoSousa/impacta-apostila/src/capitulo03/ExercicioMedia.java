package capitulo03;

import java.util.Locale;
import java.util.Scanner;

public class ExercicioMedia {
	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		
		Scanner leitor = new Scanner(System.in);
		float nt1, nt2, nt3, nt4, media, participacao;
		String abencoado;
		
		System.out.println("*** Sistema de calculo de m�dia ****");
		
		System.out.print("\nDigite a primeira nota: ");
		nt1 = leitor.nextFloat();
		System.out.print("\nDigite a segunda nota: ");
		nt2 = leitor.nextFloat();
		System.out.print("\nDigite a terceira nota: ");
		nt3 = leitor.nextFloat();
		System.out.print("\nDigite a quarta nota: ");
		nt4 = leitor.nextFloat();
		System.out.print("\nDigite a quantidade(%) sobre a frequencia do aluno: ");
		participacao = leitor.nextFloat();
		System.out.print("\nEste aluno � filho de um dos donos da escola? (S/N)");
		leitor.nextLine();
		abencoado = leitor.nextLine();
		leitor.close();
		
		media = (nt1 + nt2 + nt3 + nt4) / 4;
		System.out.println("M�dia: " + media);
		System.out.println("Frequencia: " + participacao);
	
		if(media >= 6 && participacao >= 80 || abencoado.equals("S")) {
			System.out.println("Aluno aprovado!");
		} else {
			System.out.println("Aluno reprovado!");
		}
	}
}
