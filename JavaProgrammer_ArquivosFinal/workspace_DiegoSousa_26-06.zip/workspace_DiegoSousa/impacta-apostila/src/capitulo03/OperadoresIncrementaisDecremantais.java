package capitulo03;

public class OperadoresIncrementaisDecremantais {
	public static void main(String[] args) {
		int counter = 0;
		//OPERADOR INCREMENTAL
		System.out.println("counter --> " + counter);
		counter++;
		System.out.println("counter --> " + counter);
		System.out.println("counter(++) --> " + (++counter));
		System.out.println("counter --> " + counter);
		counter++;
		counter++;
		++counter;
		System.out.println("counter --> " + counter);
		
		//OPERADOR DECREMENTAL
		System.out.println("counter --> " + counter);
		counter--;
		System.out.println("counter --> " + counter);
		System.out.println("counter(--) --> " + (--counter));
		System.out.println("counter --> " + counter);
		counter--;
		counter--;
		--counter;
		System.out.println("counter --> " + counter);
		
		
	}
}
