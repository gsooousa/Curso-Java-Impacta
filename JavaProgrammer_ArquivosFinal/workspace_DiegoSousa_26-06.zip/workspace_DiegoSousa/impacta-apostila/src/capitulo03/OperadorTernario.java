package capitulo03;

public class OperadorTernario {
	public static void main(String[] args) {
		int x = 8;
		
		if(x > 10) {
			System.out.println("x � maior que 10");
		} else {
			System.out.println("x � menor que 10");
		}
		
		
		System.out.println(x > 10 ? "Maior que 10! =)" : "Menor que 10! =(");
		
		String resultado = x > 10 ? "Sim, � maior!" : "N�o, � menor!";
		System.out.println(resultado);
		
	}
}
