package capitulo03;

public class OperadorAtribuicaoReduzida {
	public static void main(String[] args) {
		int a = 2;
		System.out.println("a = 2 --> " + a);
		a += 2; // a = a + 2
		System.out.println("a += 2 --> " + a);
		a *= 3; // a = a * 3
		System.out.println("a *= 3 --> " + a);
	}
}
