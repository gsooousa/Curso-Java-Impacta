package capitulo03;

public class OperadoresLogicos {
	public static void main(String[] args) {
		int a = 10, b = 6, c = 4;
		
		//System.out.println("Valores: a -> " + a + ", b -> " + b + ", c -> " + c);
		System.out.printf("Valores: a -> %d, b -> %d, c -> %d", a,b,c);
		
		System.out.println("\n!((a < c) && (b+2 <= a)) --> " + !((a < c) && (b+2 <= a)) );
		System.out.println("\n(a < c) && (b+2 <= a) --> " + ((a < c) && (b+2 <= a)) );
		System.out.println("\n(a < c) || (b+2 <= a) --> " + ((a < c) || (b+2 <= a)) );
		System.out.println("\n(a < c) ^ (b+2 <= a) --> " + ((a < c) ^ (b+2 <= a)) );
		
		
	}
}
