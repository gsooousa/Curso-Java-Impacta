package capitulo03.laboratorio;

public class Lab02 {
	public static void main(String[] args) {
		int valor = 7;
		System.out.println(valor % 2 == 0 ? "Par" : "Impar");
	}
}
