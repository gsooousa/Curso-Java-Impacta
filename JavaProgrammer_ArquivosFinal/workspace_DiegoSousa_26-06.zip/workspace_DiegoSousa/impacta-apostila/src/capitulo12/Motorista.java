package capitulo12;

public class Motorista {
	private String nome;
	private CNH cnh;

	public Motorista() {}

	public Motorista(String nome, CNH cnh) {
		super();
		this.nome = nome;
		this.cnh = cnh;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public CNH getCnh() {
		return cnh;
	}

	public void setCnh(CNH cnh) {
		this.cnh = cnh;
	}

}
