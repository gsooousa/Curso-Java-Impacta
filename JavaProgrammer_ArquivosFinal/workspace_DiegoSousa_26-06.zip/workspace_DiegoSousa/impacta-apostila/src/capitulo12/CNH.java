package capitulo12;

public class CNH {
	private long numeroCNH;
	private String validade;
	private String tipo;
	
	public CNH() {}
	
	public CNH(long numeroCNH, String validade, String tipo) {
		super();
		this.numeroCNH = numeroCNH;
		this.validade = validade;
		this.tipo = tipo;
	}


	public long getNumeroCNH() {
		return numeroCNH;
	}

	public void setNumeroCNH(long numeroCNH) {
		this.numeroCNH = numeroCNH;
	}

	public String getValidade() {
		return validade;
	}

	public void setValidade(String validade) {
		this.validade = validade;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
