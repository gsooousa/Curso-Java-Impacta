package capitulo12;

/**
 * Define o que e um carro dentro do problema analisado
 * 
 * @author DSousa
 * 
 * @version 1.0
 *
 */
public class Carro {
	private Motorista motorista;
	private String modelo;
	private String cor;
	private String placa;
	
	public Carro() {}
	
	public Carro(Motorista motorista, String modelo, String cor, String placa) {
		super();
		this.motorista = motorista;
		this.modelo = modelo;
		this.cor = cor;
		this.placa = placa;
	}


	/**
	 * Recupera o motorista do carro em questao
	 * 
	 * @return Um objeto do tipo Motorista
	 */
	public Motorista getMotorista() {
		return motorista;
	}

	public void setMotorista(Motorista motorista) {
		this.motorista = motorista;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

}
