package capitulo16;

import java.nio.file.Path;
import java.nio.file.Paths;

public class ExPaths {
	public static void main(String[] args) {
		Path arquivo = Paths.get("arqruivo\\exercicio.txt");
		System.out.println(arquivo.toAbsolutePath());
		System.out.println(arquivo.getFileName());
		System.out.println(arquivo.getParent());
	}
}
