package capitulo16.exercicio;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ArquivoApp {
	public static void main(String[] args) {
		List<Funcionario> funcionarios = ArquivoUtil.lerArquivo("arquivo\\exercicio.txt");
		System.out.printf("%-8s %-30s %-29s %-8s\n", "Matricula", "Nome", "Cargo", "Salario");
		funcionarios.forEach(func -> System.out.println(func));
		System.out.println("************************************************************");
		Stream<Funcionario> filtro = funcionarios.stream()
													.filter(func -> func.getCargo().equals("Desenvolvedor"));
		
		List<Funcionario> desenvolvedores = filtro.collect(Collectors.toList());
		desenvolvedores.forEach(dev -> System.out.println(dev));
		
		ArquivoUtil.gravarArquivo("arquivo\\desenvolvedores.txt", desenvolvedores);
	}
}
