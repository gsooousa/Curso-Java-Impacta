package capitulo16.exercicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class ArquivoUtil {
	
	public static List<Funcionario> lerArquivo(String file){
		String linha = null;
		String[] atributos;
		List<Funcionario> funcionarios = new ArrayList<>();
		try {
			InputStream arquivo = new FileInputStream(file);
			InputStreamReader conteudo = new InputStreamReader(arquivo);
			BufferedReader leitor = new BufferedReader(conteudo);
			leitor.readLine(); // despreza a primeira linha
			linha = leitor.readLine();
			
			while(linha != null) {
				atributos = linha.split(";");
				funcionarios.add(new Funcionario(
											Integer.parseInt(atributos[0]),
											atributos[1],
											atributos[2],
											Double.parseDouble(atributos[3])));
				
				linha = leitor.readLine();
			}
			arquivo.close();
		} catch (IOException e) {
			System.out.println("Erro ao efetuar leitura!\nErro: " + e.getMessage());
		}
		return funcionarios;
	}
	
	public static void gravarArquivo(String file, List<Funcionario> funcionarios) {
		StringBuilder conteudo = new StringBuilder();
		for(Funcionario func : funcionarios) {
			conteudo.append(func.toString() + "\n");
		}
		
		try {
			OutputStream arquivo = new FileOutputStream(file);
			OutputStreamWriter dados = new OutputStreamWriter(arquivo);
			BufferedWriter escritor = new BufferedWriter(dados);
			System.out.println(conteudo.toString());
			escritor.write(conteudo.toString());
			escritor.flush();
			escritor.close();
		} catch (IOException e) {
			System.out.println("Erro ao gravar arquivo!\nErro: " + e.getMessage());
		}
	}
}
