package capitulo16;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ExFiles {
	public static void main(String[] args) {
		try {
			Path arquivo = Paths.get("C:\\Users\\Public\\Pictures\\Sample Pictures\\Desert.jpg");
			Path pasta = Paths.get("C:\\Users\\Public\\Pictures\\Sample Pictures");
			Path novaPasta = Paths.get("C:\\Users\\Public\\Pictures\\Sample Pictures\\novo");
		
			if(!Files.exists(arquivo)) {
				System.out.println("O item n�o existe!");
			} else if(Files.isDirectory(arquivo)) {
				System.out.println("O item � um diretorio!");
			} else if(Files.isRegularFile(arquivo)){
				System.out.println("O item � um arquivo!");
			}
			
			//Exibe o tamanho do arquivo
			System.out.println(Files.size(arquivo));
			
			//Crie um novo diretorio
			Files.createDirectories(novaPasta);
			
			Files.list(pasta).forEach(f -> System.out.println(f.getFileName()));
			
		} catch (IOException e) {
			System.out.println("Erro: "+ e.getMessage());
		}
	}
}
