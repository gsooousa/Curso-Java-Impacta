package capitulo16;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;

public class ExGravacao {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite o texto a ser gravado no arquivo!");
		String texto = scan.nextLine();
		scan.close();
		try {
			OutputStream arquivo = new FileOutputStream("arquivo01.txt");
			DataOutputStream conteudo = new DataOutputStream(arquivo);
			
			conteudo.writeChars(texto);
			arquivo.close();
			System.out.println("Sucesso ao gravar informa��es no arquivo!");
		} catch (IOException e) {
			System.out.println("Erro ao gravar informa��es no arquivo!\nErro: " + e.getMessage());
		}
	}
}
