package capitulo16;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ExLeitura {
	public static void main(String[] args) {
		try {
			InputStream arquivo = new FileInputStream("arquivo01.txt");
			DataInputStream dados = new DataInputStream(arquivo);
			
			while(dados.available() > 0) {
				System.out.print(dados.readChar());
			}
			dados.close();
		} catch (IOException e) {
			System.out.println("Erro ao realizar a leitura do arquivo: " + e.getMessage());
		} 
	}
}
