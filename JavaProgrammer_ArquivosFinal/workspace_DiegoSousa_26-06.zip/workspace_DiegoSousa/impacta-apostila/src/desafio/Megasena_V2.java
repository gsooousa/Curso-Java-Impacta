package desafio;

import java.util.Arrays;

public class Megasena_V2 {
	public static void main(String[] args) {
		Integer[] jogo = {0, 0, 0, 0, 0, 0};
		int numero = 0, cont = 0;
		
		sorteio:
		do {
			//GERAR NUMERO ALEATORIO ENTRE 1 E 60
			numero = (int) (1 + Math.random() * 60);
			
			//SORTEAR 6 NUMEROS ALEATORIOS ARMAZENANDO EM UM ARRAY
			for(int i = 0; i < jogo.length; i++) {
				if(jogo[i] == 0) {
					jogo[i] = numero;
					cont++;
					continue sorteio;
				} else if(jogo[i] ==  numero) {
					continue sorteio;
				}
			}
		} while(cont < 6);
		
		//ORGANIZAR O ARRAY EM ORDEM CRESCENTE EX: 1 5 12 26 33 48
		Arrays.sort(jogo); // IoC
		
		//EXIBIR TODOS OS VALORES DO ARRAY
		System.out.printf("%02d %02d %02d %02d %02d %02d", (Object[]) jogo);
	}
}
