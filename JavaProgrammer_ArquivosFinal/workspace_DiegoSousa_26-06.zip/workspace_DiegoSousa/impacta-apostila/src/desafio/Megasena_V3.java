package desafio;

import java.util.Set;
import java.util.TreeSet;

public class Megasena_V3 {
	public static void main(String[] args) {
		Set<Integer> jogo = new TreeSet<>();
		
		while(jogo.size() < 6) {
			jogo.add((int) (1 + Math.random() * 60));
		}
		
		jogo.forEach(n -> System.out.printf("%02d ", n));
	}
}
