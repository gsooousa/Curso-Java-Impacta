package desafio;

public class Megasena_V1 {
	public static void main(String[] args) {
		int[] jogo = new int[6];
		int numero = 0;

		//SORTEAR 6 NUMEROS ALEATORIOS ARMAZENANDO EM UM ARRAY		
		for(int i =0; i < jogo.length; i++) {
			//GERAR NUMERO ALEATORIO ENTRE 1 E 60
			numero = (int) (1 + Math.random() * 60);
			jogo[i] = numero;
		}
				
		//N�O PODE HAVER NUMEROS DUPLICADOS
		for(int i = 0; i < jogo.length; i++) {
			for(int j = i+1; j < jogo.length; j++) {
				if(jogo[i] == jogo[j]) {
					jogo[i] = (int) (1 + Math.random() * 60);
					i = -1;
					break;
				}
			}
		}
		
		//ORGANIZAR O ARRAY EM ORDEM CRESCENTE EX: 1 5 12 26 33 48
		for (int i = 0; i < jogo.length; i++) {
			for (int j = i+1; j < jogo.length; j++) {
				if(jogo[i] > jogo[j]) {
					int aux = jogo[i];
					jogo[i] = jogo[j];
					jogo[j] = aux;
				}
			}
		}
		
		//EXIBIR TODOS OS VALORES DO ARRAY
		for(int i = 0; i < jogo.length; i++) {
			System.out.print(jogo[i] + " ");
		}
	}
}
