package poo;

import poo.domain.BiDimensional;
import poo.model.Figura;
import poo.model.Quadrado;

public class TesteInstanceOf {
	public static void main(String[] args) {
		Figura q = new Quadrado();
		System.out.println(q instanceof BiDimensional);
	}
}
