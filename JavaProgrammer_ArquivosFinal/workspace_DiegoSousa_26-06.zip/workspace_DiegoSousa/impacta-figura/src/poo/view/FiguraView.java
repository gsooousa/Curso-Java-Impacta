package poo.view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import poo.domain.BiDimensional;
import poo.domain.UniDimensional;
import poo.model.Figura;

public class FiguraView extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private JLabel figuraLabel;
	private JComboBox<Figura> figuraComboBox;
	private JLabel simboloLabel;
	private JTextField simboloTextField;
	private JLabel alturaLabel;
	private JSpinner alturaSpinner;
	private JLabel larguraLabel;
	private JSpinner larguraSpinner;
	private JButton desenharButton;
	private JButton limparButton;
	private DesenhoView desenhoView;
	
	public FiguraView() {
		initComponents(); //INICIA OS COMPONENTES DE TELA
		initView(); //ORAGANIZA COMO SER�O APRESENTADOS(LAYOUT)
		init(); //DEFINI INFORMA��ES SOBRE A JANELA
	}

	public void escolherFigura(ActionEvent e) {
		//DEFINI��O DE UMA VARIAVEL DE REFERENCIA DO TIPO FIGURA
		Figura f; 
		//CAPTURANDO O ITEM DO COMBOBOX(OBJECT) E CONVERTENDO PARA O TIPO FIGURA
		f = (Figura) figuraComboBox.getSelectedItem();
		
		//DE ACORDO COM A FIGURA ESCOLHIDA A TELA � MODIFICADA
		simboloTextField.setText(f.getSimbolo());
		
//		boolean isUni = f instanceof UniDimensional;
//		alturaLabel.setText(isUni ? "Lado: " : "Altura: ");
//		larguraLabel.setVisible(!isUni);
//		larguraSpinner.setVisible(!isUni);
		
		
		if(f instanceof UniDimensional) {
			alturaLabel.setText("Lado: ");
			larguraLabel.setVisible(false);
			larguraSpinner.setVisible(false);
			alturaSpinner.setValue(f.getAltura());
		} else if(f instanceof BiDimensional) {
			alturaLabel.setText("Altura: ");
			larguraLabel.setVisible(true);
			larguraSpinner.setVisible(true);
			alturaSpinner.setValue(f.getAltura());
			larguraSpinner.setValue(f.getLargura());
		}
		
		limparFigura(e);
	}
	
	public void desenharFigura(ActionEvent e) {
		Figura f;
		f = (Figura) figuraComboBox.getSelectedItem();
		
		f.setSimbolo(simboloTextField.getText());
		
		if(f instanceof UniDimensional) {
			UniDimensional d = (UniDimensional) f;
			d.setLado((int) alturaSpinner.getValue());
		} else if(f instanceof BiDimensional) {
			BiDimensional d = (BiDimensional) f;
			d.setAlt((int) alturaSpinner.getValue());
			d.setLarg((int) larguraSpinner.getValue());
		}
		
		desenhoView.preencherTextArea(f.desenhar());
		limparButton.setEnabled(true);
	}
	
	public void limparFigura(ActionEvent e) {
		desenhoView.limparTextArea();
		limparButton.setEnabled(false);
	}
	
	private void init() {
		escolherFigura(null); // Passar um valor de parametro para o m�todo
		limparButton.setEnabled(false);
		figuraComboBox.addActionListener(e -> escolherFigura(e));
		desenharButton.addActionListener(e -> desenharFigura(e));
		limparButton.addActionListener(e -> limparFigura(e));
		
		this.setTitle("Impacta Figura");
		this.setSize(280, 150);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	private void initView() {
		JPanel painel = new JPanel();
		painel.setLayout(new GridLayout(0, 2));
		
		painel.add(figuraLabel);
		painel.add(figuraComboBox);
		painel.add(simboloLabel);
		painel.add(simboloTextField);
		painel.add(alturaLabel);
		painel.add(alturaSpinner);
		painel.add(larguraLabel);
		painel.add(larguraSpinner);
		painel.add(desenharButton);
		painel.add(limparButton);
		
		this.add(painel);
		
	}

	private void initComponents() {
		figuraLabel = new JLabel("Figura: ");
		figuraComboBox = new FiguraComboBox();
		simboloLabel = new JLabel("Simbolo: ");
		simboloTextField = new JTextField("*");
		alturaLabel = new JLabel("Altura: ");
		alturaSpinner = new JSpinner(new SpinnerNumberModel(5, 0, 50, 1));
		larguraLabel = new JLabel("Largura: ");
		larguraSpinner = new JSpinner(new SpinnerNumberModel(9, 0, 50, 1));
		desenharButton = new JButton("Desenhar");
		limparButton = new JButton("Limpar");
		desenhoView = new DesenhoView();
	}
}