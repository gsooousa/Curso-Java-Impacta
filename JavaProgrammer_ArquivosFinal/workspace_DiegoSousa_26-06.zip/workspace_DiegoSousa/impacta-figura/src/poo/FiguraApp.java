package poo;

import poo.view.FiguraView;

/**
 * Esta classe dispara a chamada da tela incial do projeto Figura
 * 
 * @author DSousa
 *
 */

public class FiguraApp {
	public static void main(String[] args) {
		FiguraView tela = new FiguraView();
		tela.setVisible(true);
	}
}