package poo.model;

public class Triangulo extends Figura {
	
	public Triangulo() {
		super(5, 9, "T");
	}
	
	@Override
	public String desenhar() {
		StringBuilder desenho = new StringBuilder();
		// TODO IMPLEMENTAR A INTELIGENCIA DO DESENHO DE UM TRIANGULO 
		return desenho.toString();
	}

}
