package poo.model;

public class Losango extends Figura {
	
	public Losango() {
		super(5, 9, "L");
	}
	
	public String desenhar() {
		return "Desenhando um losango";
	}
}
