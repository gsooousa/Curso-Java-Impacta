package poo.domain;

public interface UniDimensional {
	
	void setLado(int lado);
	
}
