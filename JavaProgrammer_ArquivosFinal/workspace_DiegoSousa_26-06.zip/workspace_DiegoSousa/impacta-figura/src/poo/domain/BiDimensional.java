package poo.domain;

public interface BiDimensional {
	void setAlt(int altura);
	void setLarg(int largura);
}
