package br.com.impacta.prateleiradigital.utilitario;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import br.com.impacta.prateleiradigital.negocio.Filme;

public class FilmeUtil {
	
	public static List<Filme> extrairFilmesArquivo(String pathFile) throws Exception {
		List<Filme> filmes = new ArrayList<>();
		Scanner scan = new Scanner(Paths.get(pathFile));
		scan.nextLine();
		while(scan.hasNext()) {
			try{
				Filme filme = gerarFilme(scan.nextLine().split(";"));
				filmes.add(filme);
			} catch (Exception e) {
				continue; //Ignorar os filmes com problema no arquivo
			}
		}
		scan.close();
		return filmes;
	}
	
	public static Filme gerarFilme(String[] colunas) {
		Filme filme = new Filme(
				colunas[0],
				colunas[1], 
				converterColunaDouble(colunas[2]), 
				converterColunaInt(colunas[3]), 
				converterColunaInt(colunas[4]), 
				colunas[5], 
				converterColunaInt(colunas[6]), 
				colunas[7]);
		return filme;
	}
	
	public static int converterColunaInt(String valor) {
		if(valor == null || valor.trim().isEmpty()) {
			return -1;
		} 
		return Integer.parseInt(valor);
	}
	
	public static double converterColunaDouble(String valor) {
		if(valor == null || valor.trim().isEmpty()) {
			return -1;
		}
		return Double.parseDouble(valor);
	}
	
	
}
