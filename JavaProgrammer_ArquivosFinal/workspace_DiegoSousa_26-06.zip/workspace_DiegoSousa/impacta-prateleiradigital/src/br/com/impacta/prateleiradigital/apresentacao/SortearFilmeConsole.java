package br.com.impacta.prateleiradigital.apresentacao;

import java.util.Scanner;

import br.com.impacta.prateleiradigital.controle.FilmeController;
import br.com.impacta.prateleiradigital.negocio.Filme;

public class SortearFilmeConsole {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("*** SORTEAR FILME ***");
		System.out.println("Generos: ");
		String generos = scan.nextLine();
		System.out.println("Diretotes: ");
		String diretores = scan.nextLine();
		System.out.println("Nota: (Min) ");
		double nota = Double.parseDouble(scan.nextLine());
		System.out.println("Numero de votos: (Min) ");
		int numDeVotos = Integer.parseInt(scan.nextLine());
		scan.close();
		
		FilmeController filmeController = new FilmeController();
		try {
			Filme filme = filmeController.sortearFilme(generos, diretores, nota, numDeVotos);
			System.out.println(filme);
			System.out.println("...");
			System.out.println("Filme sorteado com sucesso!");
		} catch (Exception e) {
			System.out.println("Erro ao sortear filmes!\nErro: " + e.getMessage());
		}
			
		
		
	}
}
