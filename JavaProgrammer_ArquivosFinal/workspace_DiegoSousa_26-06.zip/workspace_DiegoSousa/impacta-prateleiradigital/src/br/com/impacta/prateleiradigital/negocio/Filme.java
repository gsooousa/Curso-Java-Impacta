package br.com.impacta.prateleiradigital.negocio;

import java.util.Calendar;

/**
 * Representa a defini��o de um filme dentro do problema analisado
 * 
 * @author Diego Sousa
 *
 * @version 1.0
 */
public class Filme {
	public static final int ANO_ATUAL = Calendar.getInstance().get(Calendar.YEAR);
	public static final int NOTA_MIN = 0;
	public static final int NOTA_MAX = 10;
	
	private String titulo;
	private String diretores;
	private double nota;
	private int duracao;
	private int ano;
	private String generos;
	private int numDeVotos;
	private String url;

	
	public Filme() {
		super();
	}
	
	public Filme(String titulo, String diretores, double nota, int duracao,
					int ano, String generos, int numDeVotos, String url) {
		super();
		setTitulo(titulo);
		setDiretores(diretores);
		setNota(nota);
		setDuracao(duracao);
		setAno(ano);
		setGeneros(generos);
		setNumDeVotos(numDeVotos);
		setUrl(url);
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDiretores() {
		return diretores;
	}

	public void setDiretores(String diretores) {
		this.diretores = diretores;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		if(nota >= NOTA_MIN && nota <= NOTA_MAX) {
			this.nota = nota;
		}
	}

	public int getDuracao() {
		return duracao;
	}

	public void setDuracao(int duracao) {
		if(duracao >= 0) {
			this.duracao = duracao;
		}
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		if(ano >= 1895 && ano <= ANO_ATUAL) { 
			this.ano = ano;
		}
	}

	public String getGeneros() {
		return generos;
	}

	public void setGeneros(String generos) {
		this.generos = generos;
	}

	public int getNumDeVotos() {
		return numDeVotos;
	}

	public void setNumDeVotos(int numDeVotos) {
		if(numDeVotos >= 0) {
			this.numDeVotos = numDeVotos;
		}
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "Filme [titulo=" + titulo + ", diretores=" + diretores + ", nota=" + nota + ", duracao=" + duracao
				+ ", ano=" + ano + ", generos=" + generos + ", numDeVotos=" + numDeVotos + ", url=" + url + "]";
	}

}
