package br.com.impacta.prateleiradigital.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.impacta.prateleiradigital.negocio.Filme;

/**
 * Classe que representa o modelo-entidade de acesso a dados do repositorio
 * 
 * @author Diego Sousa
 *
 * @version 1.0
 * 
 */
public class FilmeDAO {
	
	/**
	 * 
	 * @param filme
	 */
	public void adicionar(Filme filme) throws Exception {
		String query = "INSERT INTO tb_filmes (titulo, diretores, nota, duracao, ano, generos, numVotos, url) "
																					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		Connection conn = null;
		
		try {
			conn = getConnection();
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, filme.getTitulo());
			pst.setString(2, filme.getDiretores());
			pst.setDouble(3, filme.getNota());
			pst.setInt(4, filme.getDuracao());
			pst.setInt(5, filme.getAno());
			pst.setString(6, filme.getGeneros());
			pst.setInt(7, filme.getNumDeVotos());
			pst.setString(8, filme.getUrl());
			int rows = pst.executeUpdate();
			System.out.println(rows);
		} catch (SQLException e) {
			System.out.println("Erro ao inserir registros!\nErro: " + e.getMessage());
		} finally {
			closeConnection(conn);
		}
		
	}
	
	/**
	 * 
	 * @param titulo
	 * @param genero
	 * @param anoInicial
	 * @param anoFinal
	 * @return
	 * @throws Exception
	 */
	public List<Filme> consultar(String tituloParcial, String genero, int anoInicial, int anoFinal) throws Exception {
		String query = "SELECT * FROM tb_filmes WHERE titulo LIKE ? AND generos LIKE ? AND ano >= ? AND ano <= ?";
		List<Filme> filmes = new ArrayList<>();
		Connection conn = null;
		
		try {
			conn = getConnection();
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, tituloParcial != null ? '%'+tituloParcial.trim()+'%' : "");
			pst.setString(2, genero != null ? '%'+genero.trim()+'%' : "");
			pst.setInt(3, anoInicial);
			pst.setInt(4, anoFinal);
			ResultSet rs = pst.executeQuery();
					
			while(rs.next()) {
				String titulo = rs.getString("titulo");
				String diretores = rs.getString("diretores");
				double nota = rs.getDouble("nota");
				int duracao = rs.getInt("duracao");
				int ano = rs.getInt("ano");
				String generos = rs.getString("generos");
				int numDeVotos = rs.getInt("numVotos");
				String url = rs.getString("url");
				filmes.add(new Filme(titulo, diretores, nota, duracao, ano, generos, numDeVotos, url));
			}
		} catch (Exception e) {
			System.out.println("Erro ao selecionar registros!\nErro: " + e.getMessage());
		}
		return filmes;
	}
	
	public List<Filme> consultar(String genero, String diretor, double notaMin, int numVotos) {
		String query = "SELECT * FROM tb_filmes WHERE generos LIKE ? AND diretores LIKE ?"
															+ "AND nota > ? AND numVotos > ?";
		List<Filme> filmes = new ArrayList<>();
		Connection conn = null;
		
		try {
			conn = getConnection();
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, genero != null ? '%'+genero.trim()+'%' : "");
			pst.setString(2, diretor != null ? '%'+diretor.trim()+'%' : "");
			pst.setDouble(3, notaMin);
			pst.setInt(4, numVotos);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				String titulo = rs.getString("titulo");
				String diretores = rs.getString("diretores");
				double nota = rs.getDouble("nota");
				int duracao = rs.getInt("duracao");
				int ano = rs.getInt("ano");
				String generos = rs.getString("generos");
				int numDeVotos = rs.getInt("numVotos");
				String url = rs.getString("url");
				Filme filme = new Filme(titulo, diretores, nota, duracao, ano, generos, numDeVotos, url);
				filmes.add(filme);
			}
		} catch (Exception e) {
			System.out.println("Erro ao consultar filmes para o sorteio!\nErro: " + e.getMessage());
		} finally {
			closeConnection(conn);
		}
		return filmes;
	}

	/**
	 * 
	 * @param filme
	 */
	public void remover(Filme filme) {
		String query = "DELETE FROM tb_filmes WHERE titulo = ? AND ano = ? AND duracao = ?";
		Connection conn = null;
		
		try {
			conn = getConnection();
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, filme.getTitulo());
			pst.setInt(2, filme.getAno());
			pst.setInt(3, filme.getDuracao());
			int rows = pst.executeUpdate();
			System.out.println(rows);
		} catch (Exception e) {
			System.out.println("Erro ao excluir registro!" + e.getMessage());
		} finally {
			closeConnection(conn);
		}
	}
	
	public void importar(List<Filme> filmes) throws Exception {
		String query = "INSERT INTO tb_filmes(titulo, diretores, nota, duracao, ano, generos,numVotos, url)"
				+ " VALUES (?,?,?,?,?,?,?,?)";
		Connection conn = null;
		System.out.println("Importando filmes.. AGUARDE!");
		try {
			conn = getConnection();
			PreparedStatement pst = conn.prepareStatement(query);
			for(Filme filme : filmes) {
				pst.setString(1, filme.getTitulo());
				pst.setString(2, filme.getDiretores());
				pst.setDouble(3, filme.getNota());
				pst.setInt(4, filme.getDuracao());
				pst.setInt(5, filme.getAno());
				pst.setString(6, filme.getGeneros());
				pst.setInt(7, filme.getNumDeVotos());
				pst.setString(8, filme.getUrl());
				pst.execute();
			}
			
		} catch (SQLException e) {
			System.out.println("Erro ao importar filmes!\nErro: "+e.getMessage());
		} finally {
			closeConnection(conn);
		}
		
	}
	
	private void closeConnection(Connection conn) {
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("Erro ao fechar database: " + e.getMessage());
		}
	}
	
	private Connection getConnection() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/imdb";
		String user = "impacta";
		String password = "impacta";
		
		Connection conn = DriverManager.getConnection(url, user, password);
		
		return conn;
	}
}
