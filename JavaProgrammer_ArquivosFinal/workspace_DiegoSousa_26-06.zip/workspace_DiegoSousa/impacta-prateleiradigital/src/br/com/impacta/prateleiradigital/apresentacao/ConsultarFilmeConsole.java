package br.com.impacta.prateleiradigital.apresentacao;

import java.util.List;
import java.util.Scanner;

import br.com.impacta.prateleiradigital.controle.FilmeController;
import br.com.impacta.prateleiradigital.negocio.Filme;

public class ConsultarFilmeConsole {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("CONSULTA DE FILMES");
		System.out.print("TITULO (PARCIAL) : ");
		String titulo = scan.nextLine();
		System.out.print("GENERO: ");
		String genero = scan.nextLine();
		System.out.print("ANO (DE): ");
		int anoInicial = Integer.parseInt(scan.nextLine());
		System.out.print("ANO (ATE): ");
		int anoFinal = Integer.parseInt(scan.nextLine());
		scan.close();
		
		FilmeController filmeController = new FilmeController();
		
		try {
			List<Filme> filmes = filmeController.consultarFilme(titulo, genero, anoInicial, anoFinal);
			filmes.forEach(System.out::println);
			System.out.println("...");
			System.out.println("Filmes consultados com sucesso!");
		} catch (Exception e) {
			System.out.println("N�o existem filmes para esta pesquisa!\nErro: " + e.getMessage());
			
		}
	}

}
