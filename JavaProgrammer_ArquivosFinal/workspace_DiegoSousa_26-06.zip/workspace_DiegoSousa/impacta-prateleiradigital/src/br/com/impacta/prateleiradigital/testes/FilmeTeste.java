package br.com.impacta.prateleiradigital.testes;

import br.com.impacta.prateleiradigital.negocio.Filme;

public class FilmeTeste {
	public static void main(String[] args) {
		testeSetNotaAbaixoPermitida();
		testeSetNotaAcimaPermitida();
		testeSetNotaPermitida();
	}
	
	static void testeSetNotaPermitida() {
		Filme f = new Filme();
		double nota = 7.5;
		
		f.setNota(nota);
		
		if (f.getNota() == nota) {
			System.out.println("testeSetNotaPermitida : PASSOU");
		} else {
			System.out.println("testeSetNotaPermitida : FALHOU");
		}
	}
	
	static void testeSetNotaAcimaPermitida() {
		Filme f = new Filme();
		double nota = 11;
		
		f.setNota(nota);
		
		if(f.getNota() == 0) {
			System.out.println("testeSetNotaAcimaPermitida : PASSOU");
		} else {
			System.out.println("testeSetNotaAcimaPermitida : FALHOU");
		}
	}
	
	static void testeSetNotaAbaixoPermitida() {
		Filme f = new Filme();
		double nota = -1;
		
		f.setNota(nota);
		
		if(f.getNota() == 0) {
			System.out.println("testeSetNotaAbaixoPermitida : PASSOU");
		} else {
			System.out.println("testeSetNotaAbaixoPermitida : FALHOU");
		}
	}
}
