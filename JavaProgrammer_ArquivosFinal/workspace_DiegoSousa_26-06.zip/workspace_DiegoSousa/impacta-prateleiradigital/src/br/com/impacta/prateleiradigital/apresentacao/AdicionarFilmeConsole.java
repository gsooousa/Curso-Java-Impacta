package br.com.impacta.prateleiradigital.apresentacao;

import java.util.Scanner;

import br.com.impacta.prateleiradigital.controle.FilmeController;

public class AdicionarFilmeConsole {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("*** TELA: ADICIONAR FILME ***");
		
		System.out.print("TITULO: ");
		String titulo = scan.nextLine();
		System.out.print("DIRETORES: ");
		String diretores = scan.nextLine();
		System.out.print("NOTA: ");
		double nota = Double.parseDouble(scan.nextLine());
		System.out.print("ANO: ");
		int ano = Integer.parseInt(scan.nextLine());
		System.out.print("GENEROS: ");
		String generos = scan.nextLine();
		System.out.print("NUMERO DE VOTOS: ");
		int numDeVotos = Integer.parseInt(scan.nextLine());
		System.out.print("DURA��O (MINUTOS): ");
		int duracao = Integer.parseInt(scan.nextLine());
		System.out.print("URL: ");
		String url = scan.nextLine();
		
		scan.close();
		
		FilmeController filmeController = new FilmeController();
		try {
			filmeController.criarFilme(titulo, diretores, nota, duracao, ano, generos, numDeVotos, url);
			System.out.println("...");
			System.out.println("Filme inserido com sucesso!");
		} catch (Exception e) {
			System.out.println("Erro ao adicionar registro!\nErro: " + e.getMessage());
		}
	}
}
