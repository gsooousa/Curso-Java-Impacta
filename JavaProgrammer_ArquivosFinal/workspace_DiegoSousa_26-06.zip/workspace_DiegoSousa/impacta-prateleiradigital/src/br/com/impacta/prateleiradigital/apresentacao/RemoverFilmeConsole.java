package br.com.impacta.prateleiradigital.apresentacao;

import java.util.Scanner;

import br.com.impacta.prateleiradigital.controle.FilmeController;
import br.com.impacta.prateleiradigital.negocio.Filme;

public class RemoverFilmeConsole {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("*** REMOVER FILME ***");
		System.out.print("TITULO: ");
		String titulo = scan.nextLine();
		System.out.println("DURA��O: ");
		int duracao = Integer.parseInt(scan.nextLine());
		System.out.println("ANO: ");
		int ano = Integer.parseInt(scan.nextLine());
		scan.close();
		
		Filme filme = new Filme();
		filme.setTitulo(titulo);
		filme.setDuracao(duracao);
		filme.setAno(ano);
		
		FilmeController filmeController = new FilmeController();
		filmeController.removerFilme(filme);
		
		System.out.println("...");
		System.out.println("Filme removido com sucesso!");
		
		
	}
}
