package br.com.impacta.prateleiradigital.testes;

import br.com.impacta.prateleiradigital.negocio.Filme;

public class FilmeApp {
	public static void main(String[] args) {
		Filme f = new Filme("Avatar", "JSK", -3, -55, 2, "A, B, C", -555, "www.a.com.br");
		
		System.out.println(f.getNota());
		System.out.println(f.getDuracao());
		System.out.println(f.getAno());
		System.out.println(f.getNumDeVotos());
	}
}
