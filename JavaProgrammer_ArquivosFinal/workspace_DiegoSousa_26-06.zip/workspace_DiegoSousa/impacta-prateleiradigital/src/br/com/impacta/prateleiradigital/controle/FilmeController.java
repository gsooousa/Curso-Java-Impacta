package br.com.impacta.prateleiradigital.controle;

import java.util.Collections;
import java.util.List;

import br.com.impacta.prateleiradigital.negocio.Filme;
import br.com.impacta.prateleiradigital.persistencia.FilmeDAO;
import br.com.impacta.prateleiradigital.utilitario.FilmeUtil;

/**
 * 
 * @author Diego Sousa
 *
 * @version 1.0
 */
public class FilmeController {
	
	/**
	 * 
	 */
	FilmeDAO filmeDao = new FilmeDAO();
	
	/**
	 * Metodo responsavel pela criacao de filmes, recebendo pedido da view
	 * @param titulo
	 * @param diretores
	 * @param nota
	 * @param duracao
	 * @param ano
	 * @param generos
	 * @param numDeVotos
	 * @param url
	 */
	public void criarFilme(String titulo, String diretores, double nota, int duracao, 
								int ano, String generos, int numDeVotos, String url) throws Exception {
		Filme filme = new Filme(titulo, diretores, nota, duracao, ano, generos, numDeVotos, url);
		filmeDao.adicionar(filme);
	}
	
	/**
	 * 
	 * @param titulo
	 * @param genero
	 * @param anoInicial
	 * @param anoFinal
	 * @return
	 * @throws Exception
	 */
	public List<Filme> consultarFilme(String titulo, String genero, int anoInicial, int anoFinal)
																				throws Exception {
		List<Filme> filmes = filmeDao.consultar(titulo, genero, anoInicial, anoFinal);
		
		return filmes;
	}
	
	/**
	 * 
	 * @param filme
	 */
	public void removerFilme(Filme filme) {
		if(filme !=null) {
			filmeDao.remover(filme);
		}
	}
	
	/**
	 * 
	 * @param pathFile
	 * @throws Exception
	 */
	public void importarFilmes(String pathFile) throws Exception {
		List<Filme> filmes = FilmeUtil.extrairFilmesArquivo(pathFile);
		filmeDao.importar(filmes);
	}
	
	/**
	 * 
	 * @param generos
	 * @param diretores
	 * @param nota
	 * @param numDeVotos
	 */
	public Filme sortearFilme(String generos, String diretores, double nota, int numDeVotos) {
		List<Filme> filmes = filmeDao.consultar(generos, diretores, nota, numDeVotos);
		Collections.shuffle(filmes);
		return filmes.get(0);
	}
}
